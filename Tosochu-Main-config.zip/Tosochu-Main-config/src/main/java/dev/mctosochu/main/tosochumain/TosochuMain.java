package dev.mctosochu.main.tosochumain;

import dev.mctosochu.main.tosochumain.ScoreboardClass.BossbarMaster;
import dev.mctosochu.main.tosochumain.ScoreboardClass.SidebarMaster;
import dev.mctosochu.main.tosochumain.command.manager.CommandManager;
import dev.mctosochu.main.tosochumain.command.manager.MasterCommands;
import dev.mctosochu.main.tosochumain.config.ConfigLoader;
import dev.mctosochu.main.tosochumain.config.SpecialLocation;
import dev.mctosochu.main.tosochumain.effectiveItem.EffectiveItemManager;
import dev.mctosochu.main.tosochumain.match.SelectMatchStrategy;
import dev.mctosochu.main.tosochumain.normalizers.LobbyWorldNormalizer;
import dev.mctosochu.main.tosochumain.util.*;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

public final class TosochuMain extends JavaPlugin {

    public SpecialLocation specialLocation;

    public LobbyWorldNormalizer lobbyWorldNormalizer;

    public SelectMatchStrategy selectMatchStrategy;

    public CommandManager commandManager;
    public MasterCommands masterCommands;

    public SidebarMaster sidebarMaster;
    public BossbarMaster bossbarMaster;

    public EffectiveItemManager effectiveItemManager;

    public APIServer apiServer;

    final static public String messagePrefix =
        ChatColor.GRAY + "[" +
            "" + ChatColor.AQUA + "RunForMC Control" + ChatColor.GRAY + "]" + ChatColor.RESET + " ";

    @Override
    public void onEnable() {
        WorldInstance.disposeInstances();

        this.commandManager = new CommandManager(this);

        ConfigLoader cfgLoader = new ConfigLoader(this);

        this.specialLocation = cfgLoader.getConfig();
        this.lobbyWorldNormalizer = new LobbyWorldNormalizer(this);
        this.selectMatchStrategy = new SelectMatchStrategy(this);

        this.sidebarMaster = new SidebarMaster();
        this.bossbarMaster = new BossbarMaster();

        this.effectiveItemManager = new EffectiveItemManager(this);

        this.masterCommands = new MasterCommands(this);

        this.apiServer = new APIServer(
            this,
            "aHR0cHM6Ly90b3NvY2h1LWFwaS5hc3B1bHNlLmRldg==",
            "NFlhSXNZMVdFNDBDWWs0Y2tOYUV1czJLSERKMTBpQXZmWFEyU3JYejBXcDY3OHBkelZXcWlzbU80VHVwbFgxQg=="
        );


        getServer().getOnlinePlayers().forEach(p -> this.lobbyWorldNormalizer.normalize(p));
    }

    @Override
    public void onDisable() {
        this.sidebarMaster.disposeAll();
        this.bossbarMaster.disposeAll();
    }
}
