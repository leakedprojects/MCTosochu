package dev.mctosochu.main.tosochumain.ScoreboardClass;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class PlayerScoreboard {
    public String objectiveName;
    public String displayName;
    public Player player;
    public List<String> scoreboardTexts = new ArrayList<>();
    public HashMap<String, Integer> scoreboardTextsWithScore = new HashMap<>();

    public Scoreboard scoreboard;

    @Nullable
    public Objective objective = null;

    public List<Score> scores = new ArrayList<>();

    public PlayerScoreboard(Player player, String objectiveName, String displayName) {
        this.player = player;
        this.objectiveName = objectiveName;
        this.displayName = displayName;
        //initializing scoreboard
        ScoreboardManager scoreboardManager = Bukkit.getScoreboardManager();
        scoreboard = scoreboardManager.getNewScoreboard();
        player.setScoreboard(scoreboard);
        regenerate();

    }

    @Deprecated
    public void addLine(String text) {
        scoreboardTexts.add(text);
        Score newScore = objective.getScore(text);
        newScore.setScore(0);
        scores.add(newScore);
        for (Score s : scores) {
            s.setScore(s.getScore() + 1);
        }

    }

    public void editTexts(List<String> texts) {
        scoreboardTexts = texts;
        regenerate();
    }

    public void editTextsWithScore(HashMap<String, Integer> textsWithScore) {
        scoreboardTextsWithScore = textsWithScore;
        regenerate();
    }

    @Deprecated
    public void removeLine(int line) {
        scoreboardTexts.remove(line);
        this.regenerate();
    }

    private void regenerate() {
        scores.clear();

        if(objective != null) objective.unregister();
        objective = scoreboard.registerNewObjective(objectiveName, "dummy", displayName);
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);

        int count = this.scoreboardTexts.size();
        for (int i = 0; i < count; i++) {
            String key = scoreboardTexts.get(i);

            //HACK: キーがかぶっては表示されないため、後ろにスペースを入れて強引に回避
            while (scoreboardTexts.contains(key)) {
                key = key + " ";
            }
            scoreboardTexts.set(i, key);

            Score score = objective.getScore(key);
            score.setScore(count - i - 1);
            scores.add(score);
        }
        this.scoreboardTextsWithScore.entrySet().stream()
            .map(v -> {
                Score score = objective.getScore(v.getKey());
                score.setScore(v.getValue());
                return score;
            })
            .forEach(scores::add);
        player.setScoreboard(scoreboard);
    }

    public void unregister() {
        if (objective != null) {
            objective.unregister();
        }
    }
}
