package dev.mctosochu.main.tosochumain.match;

import dev.mctosochu.main.tosochumain.ScoreboardClass.Sidebar;
import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.config.GameMap;
import dev.mctosochu.main.tosochumain.util.ClickableItem;
import dev.mctosochu.main.tosochumain.util.ClickableItemBuilder;
import dev.mctosochu.main.tosochumain.util.GUISelector;
import dev.mctosochu.main.tosochumain.util.Util;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class MapVoteManager {
    TosochuMain plugin;
    Match match;

    GUISelector selector;
    List<GameMap> gameMaps;
    HashMap<Player, GameMap> voteResults = new HashMap<>();

    Sidebar s = new Sidebar("マップ投票");

    public MapVoteManager(TosochuMain plugin, Match match) {
        this.plugin = plugin;
        this.match = match;
        gameMaps = this.plugin.specialLocation.gameMaps;

        this.selector = new GUISelector(
            this.plugin,
            null,
            //ゲームマップの数を超える9の倍数の中で最小のもの（インベントリは一列9個のため）
            //BE版で3列未満のインベントリは表示できないため、最低27とする
            (int)Math.max( (Math.ceil(gameMaps.size() / 9.0) * 9), 27),
            "マップ投票"
        );

        gameMaps.forEach(v -> this.selector.addChoice(v.id, Material.MAP, v.mapName, "製作: " + v.author));
    }

    public HashMap<GameMap, Long> groupBy() {
        return new HashMap<>(this.voteResults.values().stream()
            .collect(Collectors.groupingBy(p -> p, Collectors.counting())));

    }

    public GameMap make() {
        HashMap<GameMap, Long> groupBy = groupBy();
        Supplier<List<GameMap>> pickableSupplier = () -> {
            if(groupBy.size() < 1) {
               return this.gameMaps;
            } else {
                long maxVote = groupBy.values().stream().max(Comparator.naturalOrder()).orElse(-1L);
                if(maxVote == -1) return this.gameMaps;
                List<GameMap> collect = groupBy.entrySet().stream()
                    .filter(v -> v.getValue() == maxVote)
                    .map(Map.Entry::getKey)
                    .collect(Collectors.toList());
                return collect.size() < 1 ? this.gameMaps : collect;
            }
        };
        final List<GameMap> pickable = pickableSupplier.get();
        return pickable.get((int) Math.floor(Math.random() * pickable.size()));
    }


    public void refreshSidebar() {
        s.editAllPlayer(sb -> sb.editTexts(new ArrayList<>() {
            {
                add("");
                groupBy().forEach((key, value) -> add(key.mapName + " (" + value + "票)"));
                add("");
                add("あなたの投票先:");
                add(Optional.ofNullable(voteResults.getOrDefault(sb.player, null)).map(v -> v.mapName).orElse("(未投票)"));
                add("");
            }
        }));
    }

    public void triggerVote(Player player) {
        this.selector.trigger(player, id -> gameMaps.stream()
            .filter(map -> map.id.equals(id))
            .findFirst()
            .ifPresent(dest -> {
                if(this.voteResults.putIfAbsent(player, dest) != null) {
                    this.voteResults.replace(player, dest);
                }
                player.sendMessage("マップ「" + dest.mapName + "」に投票しました！");
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);
                refreshSidebar();
            }));
    }

    public void initialize(Player p) {
        ClickableItem item = new ClickableItemBuilder(this.plugin)
            .setMaterial(Material.COMPASS)
            .setName(Util.getColoredString("マップ投票", ChatColor.WHITE, ChatColor.BOLD))
            .build()
            .addAction(this::triggerVote);
        p.getInventory().setItem(0, item.itemStack);
        p.setGameMode(GameMode.ADVENTURE);
        plugin.sidebarMaster.belong(p, s);
        triggerVote(p);
        refreshSidebar();
    }

    public void leave(Player p) {
        voteResults.remove(p);
        refreshSidebar();
    }
}
