package dev.mctosochu.main.tosochumain.util;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.FileFilterUtils;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Objects;
import java.util.UUID;

public class WorldInstance {
    private final World originalWorld;
    public final World world;

    public WorldInstance(World originalWorld) {
        this.originalWorld = originalWorld;
        this.world = copyWorld();
    }

    public void dispose(Location teleportTo) {
        this.world.getPlayers().forEach(p -> p.teleport(teleportTo));
        Bukkit.unloadWorld(this.world, false);
    }

    public static void disposeInstances() {
        Bukkit.getServer().getWorlds().stream()
            .filter(v -> v.getName().contains("worldinstance"))
            .forEach(v -> Bukkit.unloadWorld(v, false));
        Arrays.stream(Objects.requireNonNull(Bukkit.getWorldContainer().listFiles()))
            .filter(File::isDirectory)
            .filter(v -> v.getName().contains("worldinstance"))
            .forEach(v -> {
                try {
                    FileUtils.deleteDirectory(v);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
    }

    private World copyWorld() {
        String worldName = "worldinstance-" + this.originalWorld.getName() + "-" + UUID.randomUUID();
        IOFileFilter sessionFilter = FileFilterUtils.notFileFilter(FileFilterUtils.nameFileFilter("session.lock"));
        IOFileFilter uidFilter = FileFilterUtils.notFileFilter(FileFilterUtils.nameFileFilter("uid.dat"));
        try {
            FileUtils.copyDirectory(this.originalWorld.getWorldFolder(),
                                    new File(Bukkit.getWorldContainer() + File.separator + worldName),
                                    FileFilterUtils.and(sessionFilter, uidFilter));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new WorldCreator(worldName).createWorld();
    }
}
