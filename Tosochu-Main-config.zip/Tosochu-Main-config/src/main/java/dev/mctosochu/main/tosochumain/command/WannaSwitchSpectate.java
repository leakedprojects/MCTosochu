package dev.mctosochu.main.tosochumain.command;

import dev.mctosochu.main.tosochumain.TosochuMain;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public class WannaSwitchSpectate implements CommandExecutor {
    TosochuMain main;
    public WannaSwitchSpectate(TosochuMain plugin) {
        main = plugin;
        Objects.requireNonNull(main.getCommand("runmc-wanna-switch-spectate")).setExecutor(this);
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if(!(sender instanceof Player)) {
            sender.sendMessage("This command cannot be executed directly!");
            return true;
        }
        this.main.selectMatchStrategy.matches.stream()
            .filter(v -> v.participants.contains((Player) sender))
            .findFirst()
            .ifPresentOrElse(m -> {
                if (m.game == null) return;
                if (m.game.spectators.containsKey((Player) sender)) {
                    m.game.returnToJail(((Player) sender));
                } else {
                    m.game.wannaBeSpectate((Player) sender);
                }
            }, () -> sender.sendMessage("This command cannot be executed directly!"));
        return true;
    }
}
