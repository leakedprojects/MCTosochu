package dev.mctosochu.main.tosochumain.match;

import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.config.GameMap;
import dev.mctosochu.main.tosochumain.util.*;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

//TODO: 現状、マッチに入った状態でゲームを退出すると二度と戻れません。この仕様は改善が必要かもしれません。
public class Match implements Listener {

    //マッチ一つ一つに固有のIDをつけるためのカウンタ
    static int matchUniqueIdCounter = 0;

    public int uniqueId;

    TosochuMain plugin;

    public WorldInstance voteMap;

    @Nullable
    public Game game = null;

    //最低必要なプレイヤー数
    static final int MINIMUM_REQUIRED_PLAYERS = 4;

    BossBar startCountdown;
    @Nullable
    DispatchableTimer startCountdownTimer = null;

    //runmc match forcestart による強制ゲーム開始
    boolean forceStart = false;

    public ArrayList<Player> participants = new ArrayList<>();

    // 新しくプレイヤーが参加できるか？ <=> 試合が始まっているか？
    public boolean joinable = true;

    //Matchの終了準備が始まっているか
    public boolean releaseing = false;

    //Matchが終了したか
    public boolean released = false;

    public MapVoteManager mapVoteManager;

    public Match(TosochuMain plugin) {
        this.uniqueId = ++Match.matchUniqueIdCounter;
        this.plugin = plugin;
        this.voteMap = new WorldInstance(plugin.specialLocation.votemapWorld);
        this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
        this.mapVoteManager = new MapVoteManager(plugin, this);
        this.startCountdown = plugin.getServer().createBossBar("マッチング中...", BarColor.BLUE, BarStyle.SOLID);
        gameStartStrategy();
    }

    public void forceStart() {
        this.forceStart = true;
        gameStartStrategy();
    }

    public void voteSkip() {
        if(this.startCountdownTimer == null) return;
        this.startCountdownTimer.skipTo(5);
    }


    public void gameStartStrategy() {
        if(!joinable) return;
        if(this.participants.size() >= Match.MINIMUM_REQUIRED_PLAYERS || this.forceStart) {
            if(this.startCountdownTimer != null) return;
            this.startCountdownTimer = new DispatchableTimer(this.plugin, 60);
            this.startCountdownTimer.changeRemaining(() -> {
                if(this.startCountdownTimer.remaining.get() <= 0) return;
                this.startCountdown.setTitle("ゲーム開始まで: " + this.startCountdownTimer.remaining.get() + "秒");
                double remaining = (double)this.startCountdownTimer.remaining.get() / (double)(60);
                this.startCountdown.setProgress(Math.max(0, Math.min(remaining, 1)));
            });
            this.startCountdownTimer.schedule(0, () -> {
                this.joinable = false;
                if(this.game != null) return;
                GameMap map = this.mapVoteManager.make();
                this.startCountdown.setTitle("ゲームを開始しています (マップ: " + map.mapName + ")");
                this.startCountdown.setProgress(0);
                this.game = new Game(this.plugin, this, map);
                this.startCountdown.removeAll();
            });
        } else {
            if(this.startCountdownTimer != null) {
                this.startCountdownTimer = null;
            }
            this.startCountdown.setTitle("マッチ / " + Match.MINIMUM_REQUIRED_PLAYERS + "人集まるまで待っています...");
            this.startCountdown.setProgress(1);
        }
    }

    public void join(Player p) {
        if(!this.joinable) return;
        this.participants.add(p);
        p.sendMessage("マッチに参加しました! テレポートします...");
        p.getInventory().clear();
        this.plugin.selectMatchStrategy.teleported(p);
        p.teleport(plugin.specialLocation.getVotemapSpawn(voteMap.world));
        ClickableItem item = new ClickableItemBuilder(this.plugin)
            .setMaterial(Material.BARRIER)
            .setName(Util.getColoredString("マッチから退出する", ChatColor.RED, ChatColor.BOLD))
            .build()
            .addAction(this::leave);
        p.getInventory().setItem(8, item.itemStack);
        mapVoteManager.initialize(p);
        this.plugin.bossbarMaster.belong(p, this.startCountdown);
        this.gameStartStrategy();
    }

    // サーバーから切断した時
    @EventHandler
    public void quit(PlayerQuitEvent e) {
        disconnect(e.getPlayer());
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if(!(e.getEntity() instanceof Player && this.participants.contains((Player) e.getEntity()) && e.getEntity().getLocation().getWorld().equals(voteMap.world))) return;
        e.setCancelled(true);
    }

    // マップ投票中に「ロビーに戻る」アイテムで退出した時
    public void leave(Player p) {
        if(!this.participants.contains(p)) return;
        p.sendMessage("ロビーに戻ります...");
        disconnect(p);
        this.plugin.lobbyWorldNormalizer.normalize(p);
    }


    // 退出方法に関わらずMatchからプレイヤーを追い出す処理
    public void disconnect(Player p) {
        if(!this.participants.contains(p)) return;
        this.mapVoteManager.leave(p);
        if(this.game != null) {
            this.game.leave(p);
        }
        plugin.sidebarMaster.ripAway(p);
        plugin.bossbarMaster.ripAway(p);
        this.participants.remove(p);
        this.participants.forEach(target -> target.sendMessage(p.getName() + "さんがマッチから離脱しました"));
        if(this.game != null) {
            this.game.checkGameEndCondition();
        }
    }

    //マッチを終了させる準備をする
    public void matchGracefulRelease() {
        if(this.releaseing) return;
        this.releaseing = true;
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if(this.released) return;
            participants.forEach(p -> p.sendMessage("*このサーバーは60秒後にシャットダウンされます..."));
        }, 20L);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if(this.released) return;
            participants.forEach(p -> p.sendMessage("*このサーバーは30秒後にシャットダウンされます..."));
        }, 20L * 31);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if(this.released) return;
            participants.forEach(p -> p.sendMessage("*このサーバーは10秒後にシャットダウンされます..."));
        }, 20L * 51);
        plugin.getServer().getScheduler().runTaskLater(plugin, this::matchRelease, 20L * 61);
    }



    //マッチを終了する
    public void matchRelease() {
        if(this.released) return;
        this.releaseing = true;
        this.released = true;

        plugin.getLogger().info("Match id:" + this.uniqueId + " Released!");

        List<Player> nonNullParicipants = this.participants.stream()
            .filter(Objects::nonNull)
            .collect(Collectors.toList());

        nonNullParicipants.forEach(this::leave);

        this.voteMap.world.getPlayers().forEach(p -> plugin.lobbyWorldNormalizer.normalize(p));
        if(game != null) this.game.worldInstance.world.getPlayers().forEach(p -> plugin.lobbyWorldNormalizer.normalize(p));

        this.voteMap.world.getPlayers().forEach(p -> plugin.lobbyWorldNormalizer.normalize(p));
        if(game != null) this.game.worldInstance.world.getPlayers().forEach(p -> plugin.lobbyWorldNormalizer.normalize(p));

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if(game != null) game.release();
            voteMap.dispose(plugin.specialLocation.lobbySpawn);
        }, 80L);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> this.plugin.selectMatchStrategy.matchRelease(this), 200L);
    }
}
