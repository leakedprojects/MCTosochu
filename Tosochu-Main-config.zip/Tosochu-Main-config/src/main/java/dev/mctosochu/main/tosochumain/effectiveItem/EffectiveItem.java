package dev.mctosochu.main.tosochumain.effectiveItem;

import dev.mctosochu.main.tosochumain.TosochuMain;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;

public abstract class EffectiveItem implements Listener {
    TosochuMain plugin;

    public EffectiveItem(TosochuMain plugin) {
        this.plugin = plugin;
        this.plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    public abstract ItemStack given();
}
