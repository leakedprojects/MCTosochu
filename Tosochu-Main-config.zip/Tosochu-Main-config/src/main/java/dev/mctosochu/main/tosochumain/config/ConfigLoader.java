package dev.mctosochu.main.tosochumain.config;

import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.match.Game;
import dev.mctosochu.main.tosochumain.util.Vec3D;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.List;

import static dev.mctosochu.main.tosochumain.config.SpecialLocation.worldLoadAndGet;

public class ConfigLoader {

    private final TosochuMain pluginInstance;
    FileConfiguration config;

    public ConfigLoader(TosochuMain instance){
        pluginInstance=instance;
        pluginInstance.saveDefaultConfig();
        config=pluginInstance.getConfig();
    }

    public void reload(){
        config=pluginInstance.getConfig();
    }
    public SpecialLocation getConfig()
    {
        String LobbyWorldName;
        String VoteMapWorldName;
        Vec3D LobbySpawn;
        List<GameMap> GameMapList=new ArrayList<>();

        LobbyWorldName=config.getString("LobbyWorld");
        VoteMapWorldName=config.getString("VoteMap");
        LobbySpawn=getVec3D("LobbySpawn");

        //region GameMap
        for (String key : config.getConfigurationSection("GameMaps").getKeys(false)) {
            String id, MapName, Author, URL;
            id = config.getString("GameMaps." + key + ".id");
            MapName = config.getString("GameMaps." + key + ".MapName");
            Author = config.getString("GameMaps." + key + ".Author");
            URL = config.getString("GameMaps." + key + ".URL");

            List<Vec3D> runnerSpawnPoints = (List<Vec3D>) config.getList("GameMaps." + key + ".GameMapLocations.RunnerSpawnPoints", new ArrayList<>());
            float runnnerSpawnRotationYaw=(float)config.getDouble("GameMaps. "+ key +".GameMapLocations.RunnerSpawnRotation.yaw");
            float runnnerSpawnRotationPitch=(float)config.getDouble("GameMaps. "+ key +".GameMapLocations.RunnerSpawnRotation.pitch");
            List<Vec3D> hunterSpawnPoints = (List<Vec3D>) config.getList("GameMaps." + key + ".GameMapLocations.HunterSpawnPoints", new ArrayList<>());
            List<Vec3D> releaseToBreakBlocks = (List<Vec3D>) config.getList("GameMaps." + key + ".GameMapLocations.ReleaseToBreakBlocks", new ArrayList<>());
            Vec3D jailClosest = getVec3D("GameMaps." + key + ".GameMapLocations.JailClosest");
            Vec3D jailFarthest = getVec3D("GameMaps." + key + ".GameMapLocations.JailFarthest");
            GameMapList.add(
                new GameMap(
                    id, worldLoadAndGet(pluginInstance, MapName),
                    new GameMapLocations(
                        runnerSpawnPoints,
                        v -> w -> v.withWorld(w, runnnerSpawnRotationYaw, runnnerSpawnRotationPitch),
                        hunterSpawnPoints,
                        v -> v::withWorld,
                        releaseToBreakBlocks,
                        jailClosest,
                        jailFarthest
                        ),
                    MapName,
                    Author, URL)
            );
        }
        //endregion

        return new SpecialLocation(
            LobbyWorldName,VoteMapWorldName,LobbySpawn, GameMapList,pluginInstance
        );
    }

    private Vec3D getVec3D(String key){
        double x,y,z;;
        x=config.getDouble(key+".x");
        y=config.getDouble(key+".y");
        z=config.getDouble(key+".z");
        return new Vec3D(x,y,z);
    }
    /*Keys
    * GameMaps:
    *  MapName:
    *   id(String):
    *   MapName(String):
    *   Author(String):
    *   URL(String):
    *   GameMapLocations:
    *    RunnerSpawnPoints(List<Vec3D>):
    *     - x:
    *       y:
    *       z:
    *     - x:
    *       y:
    *       z:
    *    RunnerSpawnPointLocator(Function<Vec3D, Function<World, Location>>)
    *    HunterSpawnPoints(List<Vec3D>)
    *    HunterSpawnPointLocator(Function<Vec3D, Function<World, Location>>)
    *    ReleaseToBreakBlocks(List<Vec3D>)
    *    ?jailClosest(Vec3D)
    *    ?jailFarthest(Vec3D)
    *
    *
    * Vec3D:
    *  x:
    *  y:
    *  z:
    *
    *
    * */
}
