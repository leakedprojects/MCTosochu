package dev.mctosochu.main.tosochumain.match;

import dev.mctosochu.main.tosochumain.ScoreboardClass.Sidebar;
import org.apache.commons.codec.digest.DigestUtils;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Team;

import java.util.Date;

public class TeamBuilder {
    static void join(Player p, Match match, Sidebar sb) {
        String timeHash = DigestUtils.sha256Hex(match.uniqueId + "-" + new Date().getTime()).substring(0, 16);

        sb.getScoreboardByPlayer(p).ifPresent( psb -> {
            Team team = psb.scoreboard.registerNewTeam(timeHash);
            team.setOption(Team.Option.COLLISION_RULE, Team.OptionStatus.NEVER);
            team.addEntry(p.getName());
        });
    }
}
