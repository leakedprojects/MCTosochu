# Tosochu-Main

逃走中 in Minecraft の メインゲームロジックを実装するプラグインです。

Skriptから書き換えています。

<br>

# Getting started

Issuesに、書き換えるべきプラグインの機能が掲載されています。

自分ができるものはAssigneesに設定し、作業し終わったらプルリクエストに関連づけ、クローズしてください。

<br>

# Environment

Chiyogami 1.16.5 ( fork of Tuinity, With PAPER-API )

OpenJDK-17

Maven

<br>

# Folder Structure

成果物は`target/Tosochu-Main-(version).jar`に書き出されます。

もともとのSkriptsは、`original/`に格納されています。
