package tokyo.tosochu.aihunter.util;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import tokyo.tosochu.aihunter.Aihunter;

public class HelpBlockPlacer {
    Aihunter aihunter;
    public HelpBlockPlacer(Aihunter plugin) {
        aihunter = plugin;
    }

    public void helpBlock(Location l, Material target) {
        Block b = l.getBlock();
        Material m = b.getType();
        if(m == target) return;
        b.setType(target);

        aihunter.getServer().getScheduler().runTaskLater(aihunter, () -> {
            b.setType(m);
        }, 60);
    }
}
