package tokyo.tosochu.aihunter;

import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;
import tokyo.tosochu.aihunter.test.ShowBlockOn;
import tokyo.tosochu.aihunter.util.CommandManager;
import tokyo.tosochu.aihunter.util.HelpBlockPlacer;

public final class Aihunter extends JavaPlugin {
    final static public String messagePrefix =
            ChatColor.GRAY + "[" + ChatColor.AQUA + "AIHunter" + ChatColor.GRAY + "]" + ChatColor.RESET + " ";

    public CommandManager cm;
    public ShowBlockOn sbo;

    @Override
    public void onEnable() {
        // Plugin startup logic
        cm = new CommandManager(this);;
        sbo = new ShowBlockOn(this);

        cm.addSubCommand(new String[]{ "ping" }, p -> {
            p.say("Pong!");
            return true;
        });
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}
