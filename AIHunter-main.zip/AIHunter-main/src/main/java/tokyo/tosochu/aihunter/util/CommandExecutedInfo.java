package tokyo.tosochu.aihunter.util;

import org.bukkit.command.CommandSender;
import tokyo.tosochu.aihunter.Aihunter;

public class CommandExecutedInfo {
    public CommandSender sender;
    public String[] args;
    public CommandExecutedInfo(CommandSender sender, String[] args) {
        this.sender = sender; this.args = args;
    }
    public void say(String content) {
        sender.sendMessage(Aihunter.messagePrefix + content);
    }
}