package tokyo.tosochu.aihunter.test;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import tokyo.tosochu.aihunter.Aihunter;
import tokyo.tosochu.aihunter.util.HelpBlockPlacer;

public class ShowBlockOn implements Listener {
    Aihunter hunter;
    HelpBlockPlacer hbp;
    public boolean isEnable = false;
    public ShowBlockOn(Aihunter plugin) {
        hunter = plugin;

        hunter.getServer().getPluginManager().registerEvents(this, hunter);

        hbp = new HelpBlockPlacer(hunter);
        hunter.cm.addSubCommand(new String[]{"showblockon", "enable"}, v -> {
            v.say("ShowBlockOn Enabled!");
            isEnable = true;
            return true;
        });
        hunter.cm.addSubCommand(new String[]{"showblockon", "disable"}, v -> {
            v.say("ShowBlockOn Disabled.");
            isEnable = false;
            return true;
        });
    }

    @EventHandler
    public void onPlayerMoved(PlayerMoveEvent event) {
        if(!isEnable) return;
        hbp.helpBlock(event.getPlayer().getLocation().subtract(0, 1, 0), Material.GOLD_BLOCK);
    }

}
