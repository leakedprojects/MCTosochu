package dev.mctosochu.main.tosochumain.util;

import dev.mctosochu.main.tosochumain.TosochuMain;
import org.bukkit.entity.Player;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Base64;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class APIServer {
    TosochuMain plugin;
    String ServerUri;
    String APIKey;
    HttpClient client;

    public APIServer(TosochuMain plugin, String ServerUri, String APIKey) {
        this.plugin = plugin;
        this.ServerUri = new String(Base64.getDecoder().decode(ServerUri));
        this.APIKey = new String(Base64.getDecoder().decode(APIKey));
        client = HttpClient.newHttpClient();
    }

     public CompletableFuture<Optional<Integer>> balanceFetch(Player p) {
        this.plugin.getLogger().info("BalanceFetch triggered!: " + p.getName());
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(ServerUri + "/userdata/balance/fetch"))
            .timeout(Duration.ofSeconds(10))
            .header("Content-Type","application/json")
            .POST(
                HttpRequest.BodyPublishers.ofString(
                    "{" +
                    "\"secret\":\"" + APIKey + "\"," +
                    "\"uuid\":\"" + p.getUniqueId() + "\","  +
                    "\"name\":\"" + p.getName() + "\"" +
                    "}"
                )
            ).build();

        CompletableFuture<HttpResponse<String>> response = client.sendAsync(request, HttpResponse.BodyHandlers.ofString());

        return response.thenApply(res -> {
           this.plugin.getLogger().info("BalanceFetch Response returned!: " + p.getName());
           String body = res.body();

           Pattern successPattern = Pattern.compile("\"success\":(true|false)");
           Matcher successMatcher = successPattern.matcher(body);
           if(!successMatcher.find()) return Optional.empty();
           if(Objects.equals(successMatcher.group(1), "false")) return Optional.empty();

           Pattern balancePattern = Pattern.compile("\"balance\":([0-9]*)");
           Matcher balanceMatcher = balancePattern.matcher(body);
           if(!balanceMatcher.find()) return Optional.empty();
           return Optional.of(Integer.parseInt(balanceMatcher.group(1)));

        });
    }

    public void balanceIncrement(Player p, int amount) {
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(ServerUri + "/userdata/balance/increment"))
            .timeout(Duration.ofSeconds(10))
            .header("Content-Type","application/json")
            .POST(
                HttpRequest.BodyPublishers.ofString(
                    "{" +
                        "\"secret\":\"" + APIKey + "\"," +
                        "\"uuid\":\"" + p.getUniqueId() + "\","  +
                        "\"name\":\"" + p.getName() + "\"," +
                        "\"amount\":" + amount + "" +
                        "}"
                )
            ).build();

        client.sendAsync(request, HttpResponse.BodyHandlers.ofString());
    }
}
