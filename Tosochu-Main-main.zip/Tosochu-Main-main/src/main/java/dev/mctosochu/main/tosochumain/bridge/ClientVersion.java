package dev.mctosochu.main.tosochumain.bridge;

public class ClientVersion {
    // major versions
    public static final int VERSION_1_19_2 = 760;
    public static final int VERSION_1_16_5 = 754;
    public static final int VERSION_1_15_2 = 578;
    public static final int VERSION_1_12_2 = 340;
    public static final int VERSION_1_9 = 107;
}
