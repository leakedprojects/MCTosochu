package dev.mctosochu.main.tosochumain.util;

import dev.mctosochu.main.tosochumain.TosochuMain;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

public class ClickableItem implements Listener {
    public boolean requireOp = false;
    public Consumer<Player> p;
    public Map<EventType, Consumer<Player>> consumerMap = new HashMap<>();

    @NotNull
    public ItemStack itemStack;

    public ClickableItem(TosochuMain plugin, @NotNull ItemStack i) {
        this.itemStack = i;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }



    public ClickableItem addAction(Consumer<Player> p) {
        this.addAction(p, EventType.INTERACT, EventType.DROP_ITEM, EventType.INVENTORY_CLICK);
        return this;
    }

    public ClickableItem addAction(Consumer<Player> p, EventType... types) {
        Arrays.stream(types)
            .filter(v -> !consumerMap.containsKey(v))
            .forEach(v -> consumerMap.put(v, p)); //type supports PlayerInteractEvent, InventoryClickEvent
        return this;
    }


    public ClickableItem setRequireOp(boolean requireOp) {
        this.requireOp = requireOp;
        return this;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() == Action.PHYSICAL) return;
        if (e.getItem() != null && e.getItem().isSimilar(itemStack)) {
            e.setCancelled(true);
            execute(e.getPlayer(), e.getClass());
        }
    }


    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player)) return;
        if (e.getCurrentItem() != null && e.getCurrentItem().isSimilar(itemStack)) {
            e.setCancelled(true);
            execute((Player) e.getWhoClicked(), e.getClass());
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (e.getItemDrop().getItemStack().isSimilar(itemStack)) {
            e.setCancelled(true);
            execute(e.getPlayer(), e.getClass());
        }
    }

    private void execute(Player player, Class<? extends Event> type) {
        consumerMap.entrySet().stream()
            .filter(v -> v.getKey().getEvent().equals(type))
            .findFirst()
            .ifPresent(v -> v.getValue().accept(player));
    }

    public enum EventType {
        INTERACT(PlayerInteractEvent.class),
        DROP_ITEM(PlayerDropItemEvent.class),
        INVENTORY_CLICK(InventoryClickEvent.class);

        final Class<? extends Event> event;
        EventType(Class<? extends Event> event) {
            this.event = event;
        }

        public Class<? extends Event> getEvent() {
            return this.event;
        }
    }
}
