package dev.mctosochu.main.tosochumain.config;

import org.bukkit.World;

public class GameMap {

    public World world;

    public GameMapLocations locations;

    public String id;
    public String mapName;
    public String author;
    public String url;

    public GameMap(String id, World world, GameMapLocations locations, String mapName, String author, String url) {
        this.id = id;
        this.world = world;
        this.locations = locations;
        this.mapName = mapName;
        this.author = author;
        this.url = url;
    }
}
