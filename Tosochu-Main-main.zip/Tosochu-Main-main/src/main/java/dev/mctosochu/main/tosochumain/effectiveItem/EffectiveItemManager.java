package dev.mctosochu.main.tosochumain.effectiveItem;

import dev.mctosochu.main.tosochumain.TosochuMain;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

public class EffectiveItemManager {
    public List<EffectiveItem> runnerItems;
    public List<EffectiveItem> hunterItems;

    public EffectiveItemManager(TosochuMain plugin) {
        runnerItems = new ArrayList<>();
        runnerItems.add(new Sunglass(plugin));
        runnerItems.add(new SpeedupPotion(plugin));

        hunterItems = new ArrayList<>();
    }

    public static void setup(List<EffectiveItem> set, Player player) {
        player.getInventory().forEach(v -> {
            if (Arrays.asList(player.getInventory().getArmorContents()).contains(v)) return;
            player.getInventory().remove(v);
        });
        IntStream.range(0, set.size())
            .forEach(i -> player.getInventory().setItem(i, set.get(i).given()));
    }

    public static void discountAmount(Player p, ItemStack i) {
        //一個減らす
        final ItemStack[] items = p.getInventory().getContents();
        IntStream.range(0, items.length)
            .filter(x -> Optional.ofNullable(items[x]).map(v -> v.isSimilar(i)).orElse(false))
            .findFirst()
            .ifPresent(x -> {
                int amount = items[x].getAmount();
                if(amount > 1) {
                    items[x].setAmount(amount - 1);
                } else {
                    p.getInventory().clear(x);
                }
            });

    }
}
