package dev.mctosochu.main.tosochumain.util;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import dev.mctosochu.main.tosochumain.TosochuMain;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class Util {
    public static ItemStack getNamedItemStack(Material material, String name) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(name);
        stack.setItemMeta(meta);
        return stack;
    }

    public static String getColoredString(String value, ChatColor... colors) {
        StringBuilder builder = new StringBuilder();
        Arrays.stream(colors).forEach(v -> builder.append(v.toString()));
        return builder.append(value).toString();
    }

    //seekerがtargetのことを見えるようにしたり、見えなくしたりする
    public static void setVisibility(boolean visible, Player seeker, Player target, TosochuMain plugin) {
        if(visible) {
            seeker.showPlayer(plugin, target);
        } else {
            seeker.hidePlayer(plugin, target);
        }
    }

    public static ItemStack getColoredPotion(String name, PotionType type, Color color) {
        String typeString = type == PotionType.NORMAL ? "" : type.toString() + "_";
        ItemStack potion = new ItemStack(Material.valueOf(typeString + "POTION"));
        PotionMeta meta = (PotionMeta) potion.getItemMeta();
        meta.setDisplayName(name);
        meta.setColor(color);
        potion.setItemMeta(meta);
        return potion;
    }

    public static ItemStack getPlayerHead(Player player) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        meta.setOwningPlayer(player);
        head.setItemMeta(meta);
        return head;
    }

    public static ItemStack getCustomHead(String url, String name) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        if (url.isEmpty()) return head;

        SkullMeta meta = (SkullMeta) head.getItemMeta();
        meta.setDisplayName(name);
        GameProfile profile = new GameProfile(UUID.randomUUID(), null);

        byte[] encodedData = Base64.getEncoder().encode(String.format("{textures:{SKIN:{url:\"%s\"}}}", url).getBytes());
        profile.getProperties().put("textures", new Property("textures", new String(encodedData)));

        Field profileField;
        try {
            profileField = meta.getClass().getDeclaredField("profile");
            profileField.setAccessible(true);
            profileField.set(meta, profile);
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
            e.printStackTrace();
        }

        head.setItemMeta(meta);
        return head;
    }

    public static String stylingCurrency(int amount) {
        DecimalFormat byThree = new DecimalFormat("###,###");
        return byThree.format(amount) + "円";
    }

    public static List<PlayerPair> getPlayerPair(List<Player> players) {
        if (players.isEmpty()) return Collections.emptyList();
        List<PlayerPair> list = new ArrayList<>();
        players.forEach(p1 ->
            players.stream()
                .filter(p2 -> !p2.equals(p1))
                .filter(p2 -> !list.contains(new PlayerPair(p2, p1)))
                .forEach(p2 -> list.add(new PlayerPair(p1, p2))));
        return list;
    }

    public static class PlayerPair {
        public Player p1;
        public Player p2;
        public PlayerPair(Player p1, Player p2) {
            this.p1 = p1;
            this.p2 = p2;
        }
    }

    public enum PotionType {
        NORMAL,
        SPLASH,
        LINGERING
    }
}
