package dev.mctosochu.main.tosochumain.ScoreboardClass;

import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class BossbarMaster {
    List<BossBar> barList = new ArrayList<>();

    public void belong(Player p, BossBar b) {
        if(!barList.contains(b)) barList.add(b);
        ripAway(p);
        if (!b.getPlayers().contains(p)) {
           b.addPlayer(p);
        }
    }

    public void ripAway(Player p) {
        barList.stream()
            .filter(b -> b.getPlayers().contains(p))
            .forEach(b -> b.removePlayer(p));
    }

    public void disposeBossbar(BossBar b) {
        b.removeAll();
        barList.remove(b);
    }

    public void disposeAll() {
        new ArrayList<>(barList).forEach(this::disposeBossbar);
    }
}
