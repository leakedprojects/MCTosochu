package dev.mctosochu.main.tosochumain.ScoreboardClass;

import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

//プレイヤーがどのSidebarクラスに属すか管理します。
public class SidebarMaster {
    List<Sidebar> sidebarList = new ArrayList<>();

    public void belong(Player p, Sidebar s) {
        if(!sidebarList.contains(s)) sidebarList.add(s);
        ripAway(p);
        s.setSidebar(p);
    }

    public void ripAway(Player p) {
        sidebarList.stream()
            .filter(sidebar -> sidebar.getSidebarAllocated(p))
            .forEach(sidebar -> sidebar.removeSidebar(p));
    }

    public void disposeSidebar(Sidebar s) {
        List<Player> toDeletePlayers = s.scoreboardList.stream()
            .filter(Objects::nonNull)
            .map(v -> v.player)
            .collect(Collectors.toList());

        toDeletePlayers.forEach(s::removeSidebar);
        sidebarList.remove(s);
    }

    public void disposeAll() {
        new ArrayList<>(sidebarList).forEach(this::disposeSidebar);
    }
}
