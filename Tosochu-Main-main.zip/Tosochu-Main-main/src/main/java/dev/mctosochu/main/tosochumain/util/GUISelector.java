package dev.mctosochu.main.tosochumain.util;

import dev.mctosochu.main.tosochumain.TosochuMain;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Consumer;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class GUISelector implements Listener {
    private final Inventory inv;
    private final ArrayList<Inventorys> openQueue = new ArrayList<>();
    private final HashMap<String, ItemStack> idPair = new HashMap<>();
    TosochuMain plugin;
    public GUISelector(TosochuMain plugin,  @Nullable InventoryHolder owner, int size, @NotNull String title){
        // Create a new inventory, with no owner (as this isn't a real inventory), a size of nine, called example
        inv = Bukkit.createInventory(owner, size, title);
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }
    // You can call this whenever you want to put the items in

    public void addChoice(String id, Material Item, String Name, String... lore)
    {
        ItemStack i = createGuiItem(Item,Name,lore);
        inv.addItem(i);
        idPair.put(id, i);
    }

    public void addChoice(String id,ItemStack item)
    {
        inv.addItem(item);
        idPair.put(id, item);
    }

    public void trigger(Player player, Consumer<String> post){
        openQueue.add(new Inventorys(player, post));
        openInventory(player);
    }

    // Nice little method to create a gui item with a custom name, and description
    protected ItemStack createGuiItem(final Material material, final String name, final String... lore) {
        final ItemStack item = new ItemStack(material, 1);
        final ItemMeta meta = item.getItemMeta();

        // Set the name of the item
        meta.setDisplayName(name);

        // Set the lore of the item
        meta.setLore(Arrays.asList(lore));

        item.setItemMeta(meta);

        return item;
    }

    // You can open the inventory with this
    private void openInventory(final Player ent) {
        ent.openInventory(inv);
    }

    // Check for clicks on items
    @EventHandler
    public void onInventoryClick(final InventoryClickEvent e) {
        if (!e.getInventory().equals(inv)) return;

        e.setCancelled(true);

        final ItemStack clickedItem = e.getCurrentItem();

        // verify current item is not null
        if (clickedItem == null || clickedItem.getType().isAir()) return;

        final Player p = (Player) e.getWhoClicked();

        // Using slots click is a best option for your inventory click's
        openQueue.stream()
            .filter(queue -> p.equals(queue.player))
            .findFirst()
            .ifPresent(inv -> {
                idPair.entrySet().stream()
                    .filter(entry -> entry.getValue().equals(clickedItem))
                    .findFirst()
                    .ifPresent(set -> inv.post.accept(set.getKey()));
                openQueue.remove(inv);
            });
        if(e.getInventory().getViewers().contains(p))  p.closeInventory();
    }

    // Cancel dragging in our inventory
    @EventHandler
    public void onInventoryClick(final InventoryDragEvent e) {
        if (e.getInventory().equals(inv)) {
            e.setCancelled(true);
        }
    }

    //プレイヤーがインベントリ閉じたらQueue削除しなきゃね
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent e){
        Player p = (Player) e.getPlayer();
        if(!e.getInventory().equals(inv)) return;
        for ( int i=0;i<openQueue.size();i++)
        {
            if (openQueue.get(i).player.getName().equals(p.getName())){
                openQueue.remove(i);
                break;
            }
        }
    }


    public void resetAll(){
        resetQueue();
        inv.clear();
    }

    public void removeInventory(ItemStack item){
        inv.remove(item);
    }

    public void resetQueue(){
        openQueue.clear();
    }

    private static class Inventorys
    {
        Inventorys(Player player,Consumer<String> post){
            this.player=player;
            this.post=post;
        }
        Player player;
        Consumer<String> post;
    }
}
