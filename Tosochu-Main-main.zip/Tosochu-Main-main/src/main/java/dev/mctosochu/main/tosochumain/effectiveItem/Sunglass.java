package dev.mctosochu.main.tosochumain.effectiveItem;

import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.util.ClickableItem;
import dev.mctosochu.main.tosochumain.util.Util;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.Arrays;

public class Sunglass extends EffectiveItem{

    ItemStack item;

    public Sunglass(TosochuMain plugin) {
        super(plugin);

        item = Util.getNamedItemStack(Material.LEATHER_HELMET, "サングラス");
        item.setAmount(1);
        item.setLore(new ArrayList<>(Arrays.asList(
            "15秒間透明になる。",
            "(右クリックで使用)"
        )));

        LeatherArmorMeta meta = (LeatherArmorMeta) item.getItemMeta();
        meta.setColor(Color.BLACK);
        item.setItemMeta(meta);

        new ClickableItem(plugin, item)
            .setRequireOp(false)
            .addAction(this::use);
    }

    void use(Player p) {
        plugin.selectMatchStrategy.getGameByPlayer(p).ifPresent(g -> {
            if(!g.runners.contains(p)) return;
            EffectiveItemManager.discountAmount(p, item);
            p.sendMessage(
                "-----\n" +
                "*あなたはサングラスをかけた\n" +
                " (透明化: 15秒間, 手に持っているアイテムも見えません)\n" +
                "-----"
            );
            p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
                g.match.participants.forEach(p2 -> Util.setVisibility(false, p, p2, plugin));
                g.showBypassPlayers.add(p);
                p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0, false, false, true));
                plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                    g.showBypassPlayers.remove(p);
                    g.match.participants.forEach(p2 -> Util.setVisibility(true, p, p2, plugin));
                    p.sendMessage("*透明化が解除されました");
                    p.playSound(p.getLocation(), Sound.BLOCK_CONDUIT_DEACTIVATE, 1.0f, 1.0f);
                    p.removePotionEffect(PotionEffectType.INVISIBILITY);
                }, 20 * 15L);
        });
    }

    @Override
    public ItemStack given() {
        return item;
    }
}
