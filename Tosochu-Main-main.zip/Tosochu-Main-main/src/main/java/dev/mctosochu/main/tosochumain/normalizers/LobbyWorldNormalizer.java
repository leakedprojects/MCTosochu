package dev.mctosochu.main.tosochumain.normalizers;

import dev.mctosochu.main.tosochumain.ScoreboardClass.Sidebar;
import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.util.ClickableItem;
import dev.mctosochu.main.tosochumain.util.ClickableItemBuilder;
import dev.mctosochu.main.tosochumain.util.Util;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.Arrays;

public class LobbyWorldNormalizer implements Listener {
    private final TosochuMain plugin;
    private final ClickableItem joinItem;

    Sidebar sidebar = new Sidebar(Util.getColoredString("  逃走中 in Minecraft  ", ChatColor.WHITE, ChatColor.BOLD));

    public LobbyWorldNormalizer(TosochuMain plugin) {
        this.plugin = plugin;
        this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);

        joinItem = new ClickableItemBuilder(this.plugin)
            .setMaterial(Material.GRAY_DYE)
            .setName(Util.getColoredString("参加", ChatColor.DARK_GREEN, ChatColor.BOLD))
            .build()
            .addAction(p -> plugin.selectMatchStrategy.newComer(p));
    }

    public void normalize(Player p) {
        p.teleport(this.plugin.specialLocation.lobbySpawn);
        p.getInventory().clear();
        p.setGameMode(GameMode.ADVENTURE);
        p.setExp(0);
        p.setTotalExperience(0);
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.0F);
        p.setPlayerListName(p.getName());
        p.setFoodLevel(20);

        // 見えなくしていたプレイヤーを表示する
        plugin.getServer().getOnlinePlayers().forEach(v -> p.showPlayer(plugin, v));

        //エフェクトを消す
        removePotionEffects(p, PotionEffectType.SPEED, PotionEffectType.INVISIBILITY, PotionEffectType.BLINDNESS);

        //プレイヤーについているボスバーを削除する
        plugin.bossbarMaster.ripAway(p);

        //チームから削除
        p.getScoreboard().getTeams().forEach(v -> { if (v.hasEntry(p.getName())) v.removeEntry(p.getName()); });

        //サイドバーの設定
        this.plugin.sidebarMaster.belong(p, sidebar);

        p.getInventory().setItem(4, joinItem.itemStack);

        plugin.apiServer.balanceFetch(p).thenAccept(i ->
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                this.plugin.getLogger().info("BalanceFetch accepted!: " + p.getName());
                sidebar.getScoreboardByPlayer(p).ifPresent(sb -> {
                    plugin.getLogger().info("Scoreboard Presented!: " + p.getName());
                    sb.editTexts(new ArrayList<>() {
                        {
                            add("");
                            add(" 所持金: " + Util.stylingCurrency(i.orElse(0)));
                            add("");
                        }
                    });
                });
            }, 1L)
        );
    }

    private void removePotionEffects(Player player, PotionEffectType... effectTypes) {
        Arrays.asList(effectTypes).forEach(player::removePotionEffect);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        normalize(e.getPlayer());
    }

    @EventHandler
    public void onSaturation(FoodLevelChangeEvent e) {
        if (e.getEntityType() != EntityType.PLAYER) return;
        e.setCancelled(true);
        ((Player) e.getEntity()).setFoodLevel(20);
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntityType() != EntityType.PLAYER) return;
        if (e.getEntity().getWorld() != this.plugin.specialLocation.lobbyWorld) return;
        e.setCancelled(true);
    }
}
