package dev.mctosochu.main.tosochumain.util;

import dev.mctosochu.main.tosochumain.TosochuMain;

import java.util.*;
import java.util.function.Supplier;

public class DispatchableTimer {
    private int endTime;
    private final HashMap<Integer, List<Runnable>> funcMap = new HashMap<>();
    private final List<Runnable> changeRemaining = new ArrayList<>();
    private int lastTickedSecond = -1;
    private final TosochuMain plugin;
    private boolean forceCanceled = false;
    private final Timer timer;

    public Supplier<Integer> now = () -> (int) Math.floor((double) System.currentTimeMillis() / 1000);
    public Supplier<Integer> remaining = () -> endTime - now.get();

    public void cancel() {
        this.forceCanceled = true;
        timer.cancel();
    }

    public DispatchableTimer(TosochuMain plugin, int countDown) {
        this.plugin = plugin;
        this.endTime = countDown + (int) Math.floor((double) System.currentTimeMillis() / 1000);
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if(forceCanceled) return;
                if (funcMap.containsKey(remaining.get())) funcMap.get(remaining.get()).forEach(Runnable::run);
                if (!changeRemaining.isEmpty()) changeRemaining.forEach(Runnable::run);
                int thisTickedSecond = remaining.get();
                funcMap.entrySet().stream()
                    .filter(v -> lastTickedSecond > v.getKey() && v.getKey() >= thisTickedSecond)
                    .forEach(v -> v.getValue().forEach(Runnable::run));
                if (remaining.get() <= 0) {
                    timer.cancel();
                    funcMap.entrySet().stream()
                        .filter(v -> thisTickedSecond > v.getKey())
                        .forEach(v -> v.getValue().forEach(Runnable::run));
                }
                lastTickedSecond = thisTickedSecond;
            }
        }, 0, 1000L);
    }

    public void schedule(int time, Runnable supplier) {
        if (funcMap.containsKey(time))
            funcMap.get(time).add(() -> plugin.getServer().getScheduler().runTaskLater(this.plugin, supplier, 1L));
        else
            funcMap.put(time, Collections.singletonList(() -> plugin.getServer().getScheduler().runTaskLater(this.plugin, supplier, 1L)));
    }

    public void changeRemaining(Runnable supplier) {
        changeRemaining.add(() -> plugin.getServer().getScheduler().runTaskLater(this.plugin, supplier, 1L));
    }

    public void skipTo(int time) {
        this.endTime = this.now.get() + time;
        funcMap.entrySet().stream()
            .filter(v -> lastTickedSecond > v.getKey() &&  v.getKey() >= remaining.get())
            .sorted(Map.Entry.comparingByKey())
            .forEach(v -> {
                v.getValue().forEach(Runnable::run);
                if (!changeRemaining.isEmpty()) changeRemaining.forEach(Runnable::run);
            });
    }
}
