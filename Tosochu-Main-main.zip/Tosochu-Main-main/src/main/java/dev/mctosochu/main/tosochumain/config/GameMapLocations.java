package dev.mctosochu.main.tosochumain.config;

import dev.mctosochu.main.tosochumain.util.Vec3D;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.List;
import java.util.function.Function;

public class GameMapLocations {
    public List<Vec3D> RunnerSpawnPoints;
    public Function<Vec3D, Function<World, Location>> RunnerSpawnPointLocator;
    public List<Vec3D> HunterSpawnPoints;
    public Function<Vec3D, Function<World, Location>> HunterSpawnPointLocator;
    public List<Vec3D> ReleaseToBreakBlocks;

    public Vec3D jailClosest;
    public Vec3D jailFarthest;

    public GameMapLocations(List<Vec3D> runnerSpawnPoints, Function<Vec3D, Function<World, Location>> runnerSpawnPointLocator, List<Vec3D> hunterSpawnPoints, Function<Vec3D, Function<World, Location>> hunterSpawnPointLocator, List<Vec3D> releaseToBreakBlocks, Vec3D jailClosest, Vec3D jailFarthest) {
        this.RunnerSpawnPoints = runnerSpawnPoints;
        this.RunnerSpawnPointLocator = runnerSpawnPointLocator;
        this.HunterSpawnPoints = hunterSpawnPoints;
        this.HunterSpawnPointLocator = hunterSpawnPointLocator;
        this.ReleaseToBreakBlocks = releaseToBreakBlocks;
        this.jailClosest = jailClosest;
        this.jailFarthest = jailFarthest;
    }

    public GameMapLocations(List<Vec3D> runnerSpawnPoints, List<Vec3D> hunterSpawnPoints, List<Vec3D> releaseToBreakBlocks, Vec3D jailClosest, Vec3D jailFarthest) {
        this.RunnerSpawnPoints = runnerSpawnPoints;
        this.RunnerSpawnPointLocator = v -> v::withWorld;
        this.HunterSpawnPoints = hunterSpawnPoints;
        this.HunterSpawnPointLocator = v -> v::withWorld;
        this.ReleaseToBreakBlocks = releaseToBreakBlocks;
        this.jailClosest = jailClosest;
        this.jailFarthest = jailFarthest;
    }
}
