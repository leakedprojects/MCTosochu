package dev.mctosochu.main.tosochumain.ScoreboardClass;

import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class Sidebar {
    List<PlayerScoreboard> scoreboardList = new ArrayList<>();

    String displayName;

    public Sidebar(String displayName) {
        this.displayName = displayName;
    }

    /**
     * <summary>
     *      プレイヤーに対してサイドバーを割り当てます。重複しての割り当てにご注意ください
     *      player: プレイヤー, displayName: サイドバーのタイトル, texts: 表示するテキスト一覧
     */
    public void setSidebar(Player player) {
        //すでに割り当てがあるか確認
        removeSidebar(player);
        scoreboardList.add(new PlayerScoreboard(player,player.getName(),displayName));
    }
    /**
     * <summary>
     *      プレイヤーからサイドバーを削除します。
     *      player: プレイヤー
     */
    public void removeSidebar(Player player) {
        List<PlayerScoreboard> nonNullScoreboards = scoreboardList.stream()
            .filter(v -> v.objectiveName.equals(player.getName()))
            .collect(Collectors.toList());

        nonNullScoreboards.forEach(v -> {
            v.unregister();
            v.scoreboard.getTeams().forEach(t -> t.removeEntry(player.getName()));
            scoreboardList.remove(v);
        });
    }

    /**
     * <summary>
     *      プレイヤーに対してサイドバーが割り当てられているか確認します。
     *      割り当てられていればtrue, 割り当てられていなければfalseを返します。
     *      player: プレーヤー
     */
    public boolean getSidebarAllocated(Player player){
        return this.scoreboardList.stream()
            .anyMatch(sb -> sb.player == player);
    }

    public Optional<PlayerScoreboard> getScoreboardByPlayer(Player p) {
        return this.scoreboardList.stream()
            .filter(sb -> sb.player == p)
            .findFirst();
    }

    public void editAllPlayer(Consumer<PlayerScoreboard> consumer) {
        this.scoreboardList.forEach(consumer);
    }
}
