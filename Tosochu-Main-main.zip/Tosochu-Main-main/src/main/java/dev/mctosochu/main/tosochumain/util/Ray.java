package dev.mctosochu.main.tosochumain.util;

import org.bukkit.Material;
import org.bukkit.World;

public class Ray {
    World w;

    public Vec3D origin;
    public Vec3D target;

    public static final double RAY_INSPECT_STEP = 0.1;
    public static final double MAX_STEP = 500;

    public static boolean rayOccluding(Material m) {
        if(m == Material.BARRIER) return false;
        return m.isOccluding();
    }

    public Ray(World w, Vec3D origin, Vec3D target) {
        this.w = w;
        this.origin = origin;
        this.target = target;
    }

    public boolean reachable() {
        Vec3D position = origin.scalarScale(-1).add(target);
        Vec3D normalized = position.normalize().scalarScale(RAY_INSPECT_STEP);
        double length = position.length();

        Vec3D lastInspected = null;
        for(int i = 0; i < MAX_STEP; i++) {
            Vec3D inspect;
            if(lastInspected == null) {
                inspect = origin;
                if (rayOccluding(inspect.lattice().withWorld(w).getBlock().getType())) {
                    return false;
                }
            } else {
                inspect = lastInspected.add(normalized);
                if (!Vec3D.equal(inspect.lattice(), lastInspected.lattice())) {
                    if (rayOccluding(inspect.lattice().withWorld(w).getBlock().getType())) {
                        return false;
                    }
                }
            }
            if (length < i * RAY_INSPECT_STEP) {
                return true;
            }
            lastInspected = inspect;
        }
        return false;
    }
}
