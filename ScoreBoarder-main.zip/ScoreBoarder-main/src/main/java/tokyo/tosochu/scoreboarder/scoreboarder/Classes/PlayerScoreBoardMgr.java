package tokyo.tosochu.scoreboarder.scoreboarder.Classes;

import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Score;
import org.bukkit.scoreboard.ScoreboardManager;
import tokyo.tosochu.scoreboarder.scoreboarder.ScoreBoard_main;

import static tokyo.tosochu.scoreboarder.scoreboarder.ScoreBoarder.PluginInstance;

public class PlayerScoreBoardMgr
{
    public Player player;
    public ScoreboardMgr SManager;

    private ScoreboardMgr Original;
    public String getPlayerName()
    {
        return player.getName();
    }

    public int ShowScoreBoard(ScoreboardMgr scoreboardManager)
    {
        Original=scoreboardManager;
        if(SManager.objective!=null) {
            try {
                SManager.objective.unregister();
            } catch (IllegalStateException exc) {

            }
        }
        SManager=new ScoreboardMgr(scoreboardManager,player.getName());
        return 0;
    }

    public int ShowScoreBoard(String ScoreboardName) {
        boolean found = false;
        ScoreboardMgr scoreboardManager = null;
        for (ScoreboardMgr sbm : PluginInstance.ScoreBoardMain.ScoreBoards) {
            if (sbm.ObjectiveName.equalsIgnoreCase(ScoreboardName)) {
                scoreboardManager = sbm;
                found = true;
                break;
            }
        }

        if (!found) {
            return 1;
        }

        ShowScoreBoard(scoreboardManager);
        return 0;
    }

    public boolean ReloadScoreboardFromOriginal()
    {
        if(Original==null)
        {
            return false;
        }
        ShowScoreBoard(Original);
        return true;
    }

    public void RendScoreboard()
    {
        SManager.reloadScoreboard();
        SManager.SetScoreboardToPlayer(player);
    }

    public PlayerScoreBoardMgr(Player p){
        player=p;
        SManager=new ScoreboardMgr(p.getName());
    }

}
