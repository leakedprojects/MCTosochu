package tokyo.tosochu.scoreboarder.scoreboarder;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginDescriptionFile;
import tokyo.tosochu.scoreboarder.scoreboarder.Classes.PlayerScoreBoardMgr;
import tokyo.tosochu.scoreboarder.scoreboarder.Classes.ScoreboardMgr;

import javax.xml.soap.Text;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Objects;

import static org.bukkit.Bukkit.*;
import static tokyo.tosochu.scoreboarder.scoreboarder.ScoreBoarder.PluginInstance;
import static tokyo.tosochu.scoreboarder.scoreboarder.ScoreBoarder.PluginPrefixOnConsole;

public class Commands implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
    {
        if(command.getName().equalsIgnoreCase("scoreboarder"))
        {
            if(args.length==0){
                ShowDescription(sender);
                return true;
            }
            switch(args[0].toLowerCase(Locale.ROOT)){
                case "addtext":
                    return SubCommand_AddText(sender,args);
                case "apply":
                    return SubCommand_ApplyScoreboard(sender, args);
                case "help":
                    return SubCommand_Help(sender,args);
                case "newscoreboard":
                    return SubCommand_NewScoreboard(sender,args);
                case "reload":
                    return SubCommand_Reload(sender,args);
                case "show":
                    return SubCommand_Show(sender,args);
                case "setscore":
                    return SubCommand_SetScore(sender,args);
                case "settext":
                    return SubCommand_SetText(sender,args);
                case "setorder":
                    return SubCommand_SetOrder(sender,args);
                case "showoriginal":
                    return SubCommand_ShowOriginal(sender,args);
                //debug
                case "showscoreboardtext":
                    return Debug_ShowScoreboardText(sender,args);
                default:
                    sender.sendMessage(ChatColor.RED+PluginPrefixOnConsole+"Invalid subcommand!");
            }
        }
        return false;
    }

    boolean SubCommand_AddText(CommandSender sender,String[] args)
    {
        if(args.length>=4)
        {
            String[] TextArray=new String[args.length-3];
            for(int i=3;i<args.length;i++){
                TextArray[i-3]=args[i];
            }
            String Text=String.join(" ",TextArray);
            switch (args[1].toLowerCase())
            {
                case "template":
                    for (ScoreboardMgr sbmgr:PluginInstance.ScoreBoardMain.ScoreBoards)
                    {
                        if(sbmgr.ObjectiveName.equalsIgnoreCase(args[2])){
                            if(sbmgr.AddText(Text))
                            {
                                //complete!
                                sender.sendMessage(ChatColor.GREEN+PluginPrefixOnConsole+"Complete to add text!");
                                return true;
                            }else{
                                sender.sendMessage(ChatColor.RED+PluginPrefixOnConsole+"Failed to add text! Does the text already exists?");
                                return false;
                            }

                        }
                    }
                    break;
                case "player":
                    for (PlayerScoreBoardMgr psbmgr:PluginInstance.PlayerScoreboards)
                    {
                        if(psbmgr.getPlayerName().equalsIgnoreCase(args[2])){
                            if(psbmgr.SManager.AddText(Text))
                            {
                                //complete!
                                sender.sendMessage(ChatColor.GREEN+PluginPrefixOnConsole+"Complete to add text!");
                                return true;
                            }else{
                                sender.sendMessage(ChatColor.RED+PluginPrefixOnConsole+"Failed to add text! Does the text already exists?");
                                return false;
                            }
                        }
                    }
                    break;
                default:
                    break;
            }
        }

        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Incorrect usage! /scoreboard addtext [template/player] <Scoreboard/Player Name> <Text>");
        return false;
    }

    boolean SubCommand_ApplyScoreboard(CommandSender sender,String[] args) {
        if (args.length >= 2) {
            for (PlayerScoreBoardMgr psbmgr : PluginInstance.PlayerScoreboards) {
                if (psbmgr.getPlayerName().equalsIgnoreCase(args[1])) {
                    psbmgr.RendScoreboard();
                    sender.sendMessage(ChatColor.GREEN + PluginPrefixOnConsole + "Complete to apply the scoreboard!");
                    return false;
                }
            }
        }

        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Incorrect usage! /scoreboard apply <PlayerName>");
        return false;
    }

    boolean SubCommand_Help(CommandSender sender, String[] args) {
        PluginDescriptionFile descriptionFile = PluginInstance.getDescription();
        String HEADER = "=============<" + descriptionFile.getName() + ">=============";
        sender.sendMessage(ChatColor.GREEN + HEADER);
        sender.sendMessage(ChatColor.GREEN + "/scoreboarder");
        sender.sendMessage(ChatColor.GOLD + " addtext" + ChatColor.GREEN + ": add text to scoreboard.");
        sender.sendMessage(ChatColor.GOLD + " apply" + ChatColor.GREEN + ": display scoreboard " + ChatColor.YELLOW + ChatColor.ITALIC + "WARN" + ChatColor.RESET + ChatColor.GREEN + ": Before use this command, player CANNOT to see the scoreboard.");
        sender.sendMessage(ChatColor.GOLD + " newscoreboard" + ChatColor.GREEN + ": Create new scoreboard.");
        sender.sendMessage(ChatColor.GOLD + " setscore" + ChatColor.GREEN + ": Set score to Scoreboard");
        sender.sendMessage(ChatColor.GOLD + " settext" + ChatColor.GREEN + ": Set text to scoreboard");
        sender.sendMessage(ChatColor.GOLD + " setorder" + ChatColor.GREEN + ": Set order of scoreboard");
        sender.sendMessage(ChatColor.GOLD + " show" + ChatColor.GREEN + ": Show scoreboard to player");
        sender.sendMessage(ChatColor.GOLD + " showoriginal" + ChatColor.GREEN + ": Show original to player");
//region Make Footer
        String FOOTER = "";
        int count = HEADER.length();
        for (int i = 0; i < count; i++) {
            FOOTER = String.format("%s%s", FOOTER, "=");
        }
//endregion
        sender.sendMessage(ChatColor.GREEN + FOOTER);
        return true;
    }

    boolean SubCommand_NewScoreboard(CommandSender sender,String[] args)
    {
        return false;
    }

    boolean SubCommand_Reload(CommandSender sender,String[] args)
    {
        sender.sendMessage(String.format("%s%s%sLoading...", ChatColor.DARK_GRAY, ChatColor.ITALIC,PluginPrefixOnConsole));
        PluginInstance.ReloadConfig();
        sender.sendMessage(ChatColor.GREEN+PluginPrefixOnConsole+"Complete to reload the plugin!");
        return true;
    }

    boolean SubCommand_Show(CommandSender sender, String[] args) {

        Player player = sender.getServer().getPlayer(sender.getName());
        if (args.length > 1) {
            if(args.length==3){
                player = getServer().getPlayer(args[2]);
                if(player==null)
                {
                    sender.sendMessage(ChatColor.DARK_RED+PluginPrefixOnConsole+"Player ["+args[2]+"] was not found!");
                    return false;
                }
            }
            if(player.getName().equalsIgnoreCase("CONSOLE"))
            {
                sender.sendMessage(ChatColor.DARK_RED+PluginPrefixOnConsole+"Cannot show scoreboard to CONSOLE!");
                return false;
            }
            if (PluginInstance.ScoreBoardMain.ShowScoreboard(player, args[1]))
            {
                sender.sendMessage(ChatColor.GREEN + PluginPrefixOnConsole + "Complete to show scoreboard \"" + args[1] + "\" to "+player.getName());
                return true;
            } else {
                sender.sendMessage(ChatColor.DARK_RED + PluginPrefixOnConsole + "Scoreboard \"" + args[1] + "\" was not found!!");
                return false;
            }
        }
        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Incorrect usage! /scoreboard show <ScoreboardName>");

        return false;
    }
//region SetScore
    boolean SubCommand_SetScore(CommandSender sender,String[] args) {
        int requireLength = 5, plus = -1;
        if (args.length > 1) {
            if (args[1].equalsIgnoreCase("template") || args[1].equalsIgnoreCase("player")) {
                requireLength++;
                plus++;
            }
            if (args.length >= requireLength) {
                if (args[1].equalsIgnoreCase("player")) {
                    String[] Args = new String[args.length - 1];
                    for (int i = 2; i < args.length; i++) {
                        Args[i - 2] = args[i];
                    }
                    return SetScoreFromPlayer(sender, Args);
                } else if (args[1].equalsIgnoreCase("template")) {
                    String[] Args = new String[args.length - 2];
                    for (int i = 2; i < args.length; i++) {
                        Args[i - 2] = args[i];
                    }
                    return SetScoreFromTemplate(sender, Args);
                } else {
                    String[] Args = new String[args.length - 1];
                    for (int i = 1; i < args.length; i++) {
                        Args[i - 1] = args[i];
                    }
                    return SetScoreFromTemplate(sender, Args);
                }

            }
        }

        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Invalid usage! \n" +
                "/scoreboarder setscore [(template)/player] <ScoreboardName/PlayerName> [name/index] <ScoreboardText/Index> <Score[Integer]>");

        return false;
    }
    boolean SetScoreFromTemplate(CommandSender sender,String[] args){
        if (args[1].equalsIgnoreCase("index")) {
            if (isNumber(args[2])) {
                if (isNumber(args[3])) {
                    int ReturnVal = PluginInstance.ScoreBoardMain.SetScore(args[0], Integer.parseInt(args[2]), Integer.parseInt(args[3]));
                    if (ReturnVal == 0) {
                        return true;
                    }else if (ReturnVal == 1) {
                        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "The index number is larger than the size of the existing text!");
                        return false;
                    }
                    else if (ReturnVal == 2) {
                        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Scoreboard \"" + args[0] + "\" was not found!!");
                    }
                } else {
                    sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + args[1] + " is not integer!");
                }
            }else{
                sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + args[2] + " is not integer!");
            }
        } else if (args[1].equalsIgnoreCase("name")) {
            if (isNumber(args[3])) {
                int ReturnVal = PluginInstance.ScoreBoardMain.SetScore(args[0], args[2], Integer.parseInt(args[3]));
                if (ReturnVal == 0) {
                    return true;
                } else if (ReturnVal == 1) {
                    sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Text \"" + args[2] + "\" was not found!!");
                } else if (ReturnVal == 2) {
                    sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Scoreboard \"" + args[0] + "\" was not found!!");
                }
            } else {
                sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + args[2] + " is not integer!");
            }
        }
        return false;
    }
    boolean SetScoreFromPlayer(CommandSender sender, String[] args){
        PlayerScoreBoardMgr playerScoreBoardMgr=null;
        for (PlayerScoreBoardMgr psbm:PluginInstance.PlayerScoreboards
             ) {
            if(psbm.getPlayerName().equalsIgnoreCase(args[0])){
                playerScoreBoardMgr=psbm;
                break;
            }
        }
        if(playerScoreBoardMgr==null){
            sender.sendMessage(ChatColor.RED+PluginPrefixOnConsole+"Player was not found!!");
        }

        if (args[1].equalsIgnoreCase("index")) {
            if (isNumber(args[2])) {
                if (isNumber(args[3])) {
                    int ReturnVal = Objects.requireNonNull(playerScoreBoardMgr).SManager.SetScore( Integer.parseInt(args[2]), Integer.parseInt(args[3]));
                    if (ReturnVal == 0) {
                        return true;
                    }else if (ReturnVal == 1) {
                        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "The index number is larger than the size of the existing text!");
                        return false;
                    }
                } else {
                    sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + args[1] + " is not integer!");
                }
            }else{
                sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + args[2] + " is not integer!");
            }
        } else if (args[1].equalsIgnoreCase("name")) {
            if (isNumber(args[3])) {
                int ReturnVal = PluginInstance.ScoreBoardMain.SetScore(args[0], args[2], Integer.parseInt(args[3]));
                if (ReturnVal == 0) {
                    return true;
                } else if (ReturnVal == 1) {
                    sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Text \"" + args[2] + "\" was not found!!");
                } else if (ReturnVal == 2) {
                    sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Scoreboard \"" + args[0] + "\" was not found!!");
                }
            } else {
                sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + args[2] + " is not integer!");
            }
        }
        return false;
    }
//endregion
//region SetText
    boolean SubCommand_SetText(CommandSender sender,String[] args) {
        // 名前　index テキスト
        int requireLength = 4, plus = 0;
        if (args.length > 1) {
            if (args[1].equalsIgnoreCase("template") || args[1].equalsIgnoreCase("player")) {
                requireLength++;
                plus++;
            }
            if (args.length >= requireLength) {
                String[] Args;
                switch (args[1]) {
                    case "player":
                        Args = new String[args.length - 2];
                        for (int i = 2; i < args.length; i++) {
                            Args[i - 2] = args[i];
                        }
                        return SetTextToPlayer(sender, Args);
                    case "template":
                    default:
                        Args = new String[args.length - (1 + plus)];
                        for (int i = (1 + plus); i < args.length; i++) {
                            Args[i - (1 + plus)] = args[i];
                        }
                        return SetTextToTemplate(sender, Args);
                }
            }
        }
        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Invalid usage! /scoreboarder settext [(template)/player] <ScoreboardName/PlayerName> <Index[Integer]> <Text>");

        return false;
    }
    boolean SetTextToTemplate(CommandSender sender,String[] args) {
        String[] Texts = new String[args.length - 2];
        for (int i = 2; i < args.length; i++) {
            Texts[i - 2] = args[i];
        }
        String Text = String.join(" ", Texts);
        if (isNumber(args[1])) {
            int ReturnStr = PluginInstance.ScoreBoardMain.SetText(args[0], Integer.parseInt(args[1]), Text);
            if (ReturnStr == 0) {
                return true;
            } else if (ReturnStr == 1) {
                sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "The index number is larger than the size of the existing text!");
                return false;
            }
        }
        return false;
    }
    boolean SetTextToPlayer(CommandSender sender,String[] args)    {
        String[] Texts=new String[args.length-2];
        for(int i=2;i< args.length;i++){
            Texts[i-2]=args[i];
        }
        String Text=String.join(" ",Texts);

        for (PlayerScoreBoardMgr psbmgr:PluginInstance.PlayerScoreboards
             ) {
            if(psbmgr.getPlayerName().equalsIgnoreCase(args[0])){
                switch (psbmgr.SManager.SetText(Integer.parseInt(args[1]), Text))
                {
                    case 0:
                        sender.sendMessage(ChatColor.GREEN + PluginPrefixOnConsole + "Complete to change the text!");
                        return true;
                    case 1:
                        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "The index number is larger than the size of the existing text!");
                        return false;

                }
            }

        }
        sender.sendMessage(ChatColor.DARK_RED+PluginPrefixOnConsole+"Player "+args[0]+" was not found!!");
        return false;
    }

//endregion
//region SetOrder
    boolean SubCommand_SetOrder(CommandSender sender,String[] args) {
        int requireLength = 4, plus = 0;
        if (args.length > 1) {
            if (args[1].equalsIgnoreCase("template") || args[1].equalsIgnoreCase("player")) {
                requireLength++;
                plus++;
            }
            if (args.length >= requireLength) {
                String[] Args;
                switch (args[1].toLowerCase()) {
                    case "player":
                        Args = new String[args.length - 2];
                        for (int i = 2; i < args.length; i++) {
                            Args[i - 2] = args[i];
                        }
                        return SetOrderToPlayer(sender, Args);
                    case "template":
                    default:
                        Args = new String[args.length - (1 + plus)];
                        for (int i = (1 + plus); i < args.length; i++) {
                            Args[i - (1 + plus)] = args[i];
                        }
                        return SetOrderToTemplate(sender, Args);
                }

            }
        }
        // invalid
        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Invalid arguments!" + ChatColor.GREEN + " /scoreboarder setorder [(template)/player] <ScoreboardName> <Index(Integer)> <Setting destination(Integer)>");

        return false;
    }
    boolean SetOrderToTemplate(CommandSender sender, String[] args){
        if (isNumber(args[1])) {
            if (isNumber(args[2])) {
                int ReturnValue = PluginInstance.ScoreBoardMain.SetOrder(args[0], Integer.parseInt(args[1]), Integer.parseInt(args[2]));
                switch (ReturnValue) {
                    case 0:
                        sender.sendMessage(ChatColor.GREEN + PluginPrefixOnConsole + "Successful to change the order!");

                        return true;
                    case 1:
                        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Setting destination is bigger than the size of Scoreboard!");
                        return false;
                    case 2:
                        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Index is bigger than the size of Scoreboard!");
                        return false;
                    case 3:
                        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Scoreboard \"" + args[0] + "\" was not found!");
                        return false;
                }


            } else {
                sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "\"" + args[2] + "\" is not an Integer!");
                return false;
            }
        } else {
            sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "\"" + args[1] + "\" is not an Integer!");
            return false;
        }
        return false;
    }
    boolean SetOrderToPlayer(CommandSender sender, String[] args){
        PlayerScoreBoardMgr playerScoreBoardMgr=null;
        for (PlayerScoreBoardMgr psbmgr: PluginInstance.PlayerScoreboards
             ) {
            if(psbmgr.getPlayerName().equalsIgnoreCase(args[0])){
                playerScoreBoardMgr=psbmgr;
            }
        }
        if(playerScoreBoardMgr==null){
            sender.sendMessage(ChatColor.DARK_RED+PluginPrefixOnConsole+"Player "+args[0]+" was not found!!");
            return false;
        }
        if (isNumber(args[1])) {
            if (isNumber(args[2])) {

                int ReturnValue = playerScoreBoardMgr.SManager.SetOrder(Integer.parseInt(args[1]), Integer.parseInt(args[2]));
                switch (ReturnValue) {
                    case 0:
                        sender.sendMessage(ChatColor.GREEN + PluginPrefixOnConsole + "Successful to change the order!");
                        return true;
                    case 1:
                        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Setting destination is bigger than the size of Scoreboard!");
                        return false;
                    case 2:
                        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Index is bigger than the size of Scoreboard!");
                        return false;
                    case 3:
                        sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Scoreboard \"" + args[0] + "\" was not found!");
                        return false;
                }


            } else {
                sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "\"" + args[2] + "\" is not an Integer!");
                return false;
            }
        } else {
            sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "\"" + args[1] + "\" is not an Integer!");
            return false;
        }
        return false;
    }
//endregion
//region ShowOriginal
    boolean SubCommand_ShowOriginal(CommandSender sender, String[] args) {
        if (args.length >= 2) {
            for (PlayerScoreBoardMgr psbmgr:PluginInstance.PlayerScoreboards                 )
            {
                if(psbmgr.getPlayerName().equalsIgnoreCase(args[1])){
                    if(!psbmgr.ReloadScoreboardFromOriginal())
                    {
                        sender.sendMessage(ChatColor.RED+PluginPrefixOnConsole+args[1]+" has not displayed any scoreboard!!");
                        return false;
                    }
                    sender.sendMessage(ChatColor.GREEN+PluginPrefixOnConsole+"Complete to show Original scoreboard to "+args[1]);
                    return true;
                }
            }
            sender.sendMessage(ChatColor.DARK_RED+PluginPrefixOnConsole+"Player "+args[1]+" was not found!!");
        } else {
            sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + "Incorrect usage! /scoreboarder showoriginal <PlayerName>");
        }
        return false;
    }
//endregion

//region Debug Functions
    boolean Debug_ShowScoreboardText(CommandSender sender,String[] args)
    {
        if(args.length > 2)
        {
            if(args[1].equalsIgnoreCase("template"))
            {
                for (ScoreboardMgr sbmgr: PluginInstance.ScoreBoardMain.ScoreBoards)
                {
                    if(sbmgr.ObjectiveName.equalsIgnoreCase(args[2]))
                    {
                        sender.sendMessage(ChatColor.GRAY + PluginPrefixOnConsole + "They are the text of "+args[2]+"...");
                        for(String text:sbmgr.ScoreBoardTexts)
                        {
                            sender.sendMessage(ChatColor.GOLD+"- "+text);
                        }
                        return true;
                    }

                }

                sender.sendMessage(
                        String.format("%s%sTemplate %s%s%s%s%s was not found!",
                                ChatColor.DARK_RED,PluginPrefixOnConsole,ChatColor.UNDERLINE,args[2],ChatColor.RESET,ChatColor.DARK_RED," was not found!!!"));
            }else if(args[1].equalsIgnoreCase("player")){

                for (PlayerScoreBoardMgr sbmgr: PluginInstance.PlayerScoreboards)
                {
                    if(sbmgr.SManager.ObjectiveName.equalsIgnoreCase(args[2]))
                    {
                        sender.sendMessage(ChatColor.GRAY + PluginPrefixOnConsole + "They are the text of player "+args[2]+"...");
                        for(String text:sbmgr.SManager.ScoreBoardTexts)
                        {
                            sender.sendMessage(ChatColor.GOLD+"- "+text);
                        }
                        return true;
                    }
                }

            }
        }
        sender.sendMessage(ChatColor.RED+PluginPrefixOnConsole+"showscoreboardtext [template/player] <name>");
        return false;
    }

//endregion

//region OtherFunctions
    public boolean isNumber(String val) {
        if (val.charAt(0) == '-') { //マイナスかどうかを検知
            if(val.length()<2){
                //'-'しか入っていない
                return false;
            }
            //'-'を取り除いた文字列が数値かどうか判別
            return val.substring(1).chars().allMatch(Character::isDigit);
        } else {
            return val.chars().allMatch(Character::isDigit);
        }
    }
//endregion
    void ShowDescription(CommandSender sender) //説明
    {
        PluginDescriptionFile descriptionFile=PluginInstance.getDescription();
        String HEADER = "=============<"+descriptionFile.getName()+">=============";
        sender.sendMessage(ChatColor.GREEN+HEADER);
        sender.sendMessage(ChatColor.GREEN+" Version: "+descriptionFile.getVersion());
        sender.sendMessage(ChatColor.GREEN+" Author: "+descriptionFile.getAuthors());
        sender.sendMessage(ChatColor.GREEN+" "+ChatColor.GOLD+"/scoreboarder help"+ChatColor.GREEN+" to show help!");
        String FOOTER = "";
        int count=HEADER.length();
        for(int i=0;i<count;i++){
            FOOTER = String.format("%s%s",FOOTER,"=");
        }
        sender.sendMessage(ChatColor.GREEN+FOOTER);
    }
}
