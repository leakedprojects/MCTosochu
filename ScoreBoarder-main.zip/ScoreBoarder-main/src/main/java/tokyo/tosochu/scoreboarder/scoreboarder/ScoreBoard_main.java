package tokyo.tosochu.scoreboarder.scoreboarder;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;
import tokyo.tosochu.scoreboarder.scoreboarder.Classes.PlayerScoreBoardMgr;
import tokyo.tosochu.scoreboarder.scoreboarder.Classes.ScoreboardMgr;

import java.rmi.server.RemoteServer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

import static tokyo.tosochu.scoreboarder.scoreboarder.ScoreBoarder.PluginInstance;
import static tokyo.tosochu.scoreboarder.scoreboarder.ScoreBoarder.PluginPrefixOnConsole;

//スコアボードのメインとなるクラス
public class ScoreBoard_main
{

    ScoreboardManager scoreboardManager = Bukkit.getScoreboardManager();
    final String ScoreboardConfigPath = "Scoreboards";
    public List<ScoreboardMgr> ScoreBoards = new ArrayList<>();
    //Configからスコアボード読み込む関数
    public void LoadScoreboardFromConfig()
    {
        //PluginInstanceのほうのconfigのアドレス受け取る

        FileConfiguration config=PluginInstance.config;


        if(config.getConfigurationSection(ScoreboardConfigPath) == null)
        {
            System.out.println(PluginPrefixOnConsole+"There is no Scoreboards! Adding Default Board...");

            config.set(ScoreboardConfigPath+".default.DisplayName","default");
        }else {
            for (String key :config.getConfigurationSection(ScoreboardConfigPath).getKeys(false)) {
                System.out.println(PluginPrefixOnConsole+"Loading \""+key+"\" scoreboard...");
                ScoreboardMgr sbm = new ScoreboardMgr(key);
                sbm.LoadScoreboardFromConfig();
                ScoreBoards.add(sbm);
            }
        }
    }

    public boolean ShowScoreboard(Player player,String ScoreboardName)
    {
        for(PlayerScoreBoardMgr psbmgr: PluginInstance.PlayerScoreboards)
        {
            if(psbmgr.getPlayerName().equalsIgnoreCase(player.getName())){
                int returnvalue = psbmgr.ShowScoreBoard(ScoreboardName);
                return returnvalue == 0;
            }
        }

        return false;
    }

    public int SetScore(String ObjectiveName,String ScoreboardText,int Score)
    {
        for(ScoreboardMgr sbm: ScoreBoards)
        {
            if(sbm.ObjectiveName.equals(ObjectiveName))
            {
                int count = sbm.ScoreBoardTexts.size();
                for(int i=0;i<count;i++)
                {
                    if(sbm.ScoreBoardTexts.get(i).equalsIgnoreCase(ScoreboardText))
                    {
                        sbm.SetScore(Score,i);
                        return 0;
                    }
                }
                Bukkit.getLogger().warning(PluginPrefixOnConsole+"Text \""+ScoreboardText+"\" was not found!!");
                return 1;
            }
        }
        Bukkit.getLogger().warning(PluginPrefixOnConsole+"Scoreboard \""+ObjectiveName+"\" was not found!!");
        return 2;
    }

    public int SetScore(String ObjectiveName,int index,int Score)
    {
        for(ScoreboardMgr sbm: ScoreBoards)
        {
            if(sbm.ObjectiveName.equals(ObjectiveName)) {
                int count = sbm.ScoreBoardTexts.size();
                if(count<=index){
                    return 1;
                }
                sbm.SetScore(Score, index);
                return 0;
            }
        }
        Bukkit.getLogger().warning(PluginPrefixOnConsole+"Scoreboard \""+ObjectiveName+"\" was not found!!");
        return 2;
    }

    public int SetText(String ObjectiveName,int index,String Text)
    {
        for(ScoreboardMgr sbm: ScoreBoards){
            if(sbm.ObjectiveName.equalsIgnoreCase(ObjectiveName)){
                if(sbm.ScoreBoardTexts.size()<=index){
                    return 1;
                }
                sbm.ScoreBoardTexts.set(index,sbm.CheckReservable(Text));
                int score = sbm.ScoreboardScores.get(index).getScore();
                sbm.ScoreboardScores.set(index,sbm.objective.getScore(sbm.CheckReservable(Text)));
                sbm.ScoreboardScores.get(index).setScore(score);
                sbm.reloadScoreboard();
                return 0;
            }
        }
        return 2;
    }

    public int SetOrder(String ObjectiveName,int index,int setTo)
    {
        for(ScoreboardMgr sbr: ScoreBoards){
            if(!sbr.ObjectiveName.equals(ObjectiveName)) continue;
            if(sbr.ScoreBoardTexts.size() <= index) return 2;
            if(sbr.ScoreBoardTexts.size() > setTo){
                sbr.ChangeOrderTo(index, setTo);
                return 0;
            }else {
                return 1;
            }
        }
        return 3;

    }

    public void AllDelete()
    {
        for (ScoreboardMgr sbmgr: ScoreBoards)
        {
            sbmgr.objective.unregister();
        }
        ScoreBoards.clear();
    }
    //コンストラクタ
    public ScoreBoard_main()
    {

    }
}
