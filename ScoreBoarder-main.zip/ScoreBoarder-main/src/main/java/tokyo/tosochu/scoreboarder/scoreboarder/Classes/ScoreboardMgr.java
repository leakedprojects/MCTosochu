package tokyo.tosochu.scoreboarder.scoreboarder.Classes;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

import java.util.ArrayList;
import java.util.List;

import static tokyo.tosochu.scoreboarder.scoreboarder.ScoreBoarder.PluginInstance;
import static tokyo.tosochu.scoreboarder.scoreboarder.ScoreBoarder.PluginPrefixOnConsole;

public class ScoreboardMgr {
    public String ObjectiveName;
    public String DisplayName;
    public List<String> ScoreBoardTexts = new ArrayList<>();
    final String ScoreboardConfigPath = "Scoreboards";
    private ScoreboardManager scoreboardManager;
    Scoreboard scoreBoard;
    public Objective objective;

    public List<Score> ScoreboardScores = new ArrayList<>();

    public void SetScoreboardToPlayer(Player player) {
        System.out.println(PluginPrefixOnConsole + "Trying to show Scoreboard \"" + ObjectiveName + "\" to " + player.getName());

        player.setScoreboard(scoreBoard);
    }

    public void ChangeOrderTo(int index, int move) {
        int addvalue = (index > move) ? -1 : 1;
        String str;
        for (int i = index; i != move; i += addvalue) {
            if (i < 0 || i >= ScoreBoardTexts.size()) {
                Bukkit.getLogger().warning(PluginPrefixOnConsole + "ScoreBoard_Main.ChangeOrderTo(): Cannot continue the loop!");
                break;
            }
            str = ScoreBoardTexts.get(i);
            ScoreBoardTexts.set(i, ScoreBoardTexts.get(i + addvalue));
            ScoreBoardTexts.set(i + addvalue, str);

        }
    }
//region Text etc...
    public boolean AddText(String Text)
    {
        
        if(ScoreBoardTexts.contains(Text)) { return false; }

        ScoreBoardTexts.add(Text);
        return true;
        /*if(objective==null){
        }*/
       /* Score score=objective.getScore(Text);
        score.setScore(0);
        ScoreboardScores.add(score);
        for (Score score1: ScoreboardScores
             ) {
            score1.setScore(score1.getScore()+1);
        }
        return true;*/
    }

    public int SetText(int index,String Text) {
        if (ScoreBoardTexts.size() <= index) {
            return 1;
        }
        ScoreBoardTexts.set(index, CheckReservable(Text));
        return 0;
    }
//endregion
//region Order etc..
public int SetOrder(int index,int setTo)
{

        if(ScoreBoardTexts.size() <= index) return 2;
        if(ScoreBoardTexts.size() > setTo){
            ChangeOrderTo(index, setTo);
            return 0;
        }else {
            return 1;
        }


}
//endregion
//region Reload
    public void reloadScoreboard() {
        List<Integer> scores = new ArrayList<>();
        for (Score score : ScoreboardScores) {
            scores.add(score.getScore());
        }
        ScoreboardScores.clear();
        if(objective!=null) {
            try {
                objective.unregister();
            } catch (IllegalStateException exc) {
            }
        }
        scoreBoard = scoreboardManager.getNewScoreboard();
        objective = scoreBoard.registerNewObjective(ObjectiveName, "dummy");
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        objective.setDisplayName(DisplayName);
        int count = ScoreBoardTexts.size();
        for (int i = 0; i < count; i++) {
            Score score = objective.getScore(ScoreBoardTexts.get(i));
            System.out.println("\t"+ScoreBoardTexts.get(i));
            if (i >= scores.size())
            {
                score.setScore(1);
                int scorescount=scores.size();
                for(int j=0;j<scorescount;j++){
                    ScoreboardScores.get(j).setScore(ScoreboardScores.get(j).getScore() + 1);
                }
            } else {
                score.setScore(scores.get(i));
            }
            ScoreboardScores.add(score);
        }
    }
//endregion
//region LoadScoreboard
    public void LoadScoreboardFromConfig() {
        FileConfiguration config = PluginInstance.config;


        String ReturnStr = config.getString(ScoreboardConfigPath + "." + ObjectiveName + ".DisplayName", "NULL");
        if (ReturnStr.equals("NULL")) {
            Bukkit.getLogger().warning(PluginPrefixOnConsole + ScoreboardConfigPath + "." + ObjectiveName + ".DisplayName was not set! setting " + DisplayName);
            config.set(ScoreboardConfigPath + ".DisplayName", DisplayName);
        } else {
            Bukkit.getLogger().info(PluginPrefixOnConsole + "Setting \"" + ReturnStr + "\" to DisplayName of Scoreboard \"" + ObjectiveName + "\"");
            DisplayName = ReturnStr;
        }

        List<String> ReturnListStr;
        ReturnListStr = (List<String>) config.getList(ScoreboardConfigPath + "." + ObjectiveName + ".Texts");
        if (ReturnListStr == null) {
            //記述なし
            System.out.println(PluginPrefixOnConsole + "Scoreboard has not described!");
            ScoreBoardTexts = new ArrayList<>();
            ScoreBoardTexts.add("Example");
            config.set(ScoreboardConfigPath + "." + ObjectiveName + ".Texts", ScoreBoardTexts);
        } else {
            //記述あり。読み込む。
            System.out.println(PluginPrefixOnConsole + "Loading Scoreboard...");
            int order = ReturnListStr.size();
            for (String str : ReturnListStr) {
                str = CheckReservable(str);
                switch (str) {
                    case " ":
                        Bukkit.getLogger().info(PluginPrefixOnConsole + "Adding \"" + "[SPACE]" + "\" to Scores of Scoreboard \"" + ObjectiveName + "\"");
                        break;
                    default:
                        Bukkit.getLogger().info(PluginPrefixOnConsole + "Adding \"" + str + "\" to Scores of Scoreboard \"" + ObjectiveName + "\"");
                        break;
                }
                ScoreBoardTexts.add(str);
                Score score = objective.getScore(str);
                score.setScore(order);
                ScoreboardScores.add(score);
                order--;
            }

            System.out.println(PluginPrefixOnConsole + "Scoreboard \"" + ObjectiveName + "\" has loaded!");
        }
    }

    //endregion
//region SetScore
    public int SetScore(int Score, int Index) {
        if(ScoreboardScores.size() <= Index){
            return 1;
        }
        ScoreboardScores.get(Index).setScore(Score);
        return 0;
    }

    public void SetScore(int Score, String Text) {
        int count = ScoreBoardTexts.size();
        for (int i = 0; i < count; i++) {
            if (ScoreBoardTexts.get(i).equalsIgnoreCase(Text)) {
                SetScore(Score, i);
                return;
            }
        }
        Bukkit.getLogger().warning(PluginPrefixOnConsole + "Scoreboard Text \"" + Text + "\" was not found!!!");
        return;
    }
    //endregion
//region Constructor

    public ScoreboardMgr(ScoreboardMgr scoreboardMgr, String objectiveName) {
        scoreboardManager = Bukkit.getScoreboardManager();
        scoreBoard = scoreboardManager.getNewScoreboard();
        ObjectiveName = objectiveName;
        this.DisplayName = scoreboardMgr.DisplayName;
        ScoreBoardTexts = new ArrayList<>(scoreboardMgr.ScoreBoardTexts);
        ScoreboardScores = new ArrayList<>(scoreboardMgr.ScoreboardScores);
        Objective objective = scoreBoard.registerNewObjective(ObjectiveName, "dummy");
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        objective.setDisplayName(scoreboardMgr.DisplayName);
        for (int i = 0; i < ScoreBoardTexts.size(); i++) {
            Score score = objective.getScore(ScoreBoardTexts.get(i));
            score.setScore(scoreboardMgr.ScoreboardScores.get(i).getScore());
        }
    }

    public ScoreboardMgr(String objectiveName) {
        scoreboardManager=Bukkit.getScoreboardManager();
        scoreBoard = scoreboardManager.getNewScoreboard();
        this.ObjectiveName = objectiveName;
        objective = scoreBoard.registerNewObjective(ObjectiveName, "dummy");
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
    }


    // endregion
//region Privates
    public String CheckReservable(String text) { //置き換えられる文字列か調べる
        reserved_word[] Reserverd_Words =
                {
                        new reserved_word("$SPACE", " ")
                };
        int count = Reserverd_Words.length;
        for (int i = 0; i < count; i++) {
            if (Reserverd_Words[i].ReservableText.equals(text)) {
                String ChangeTextTo = Reserverd_Words[i].SubstituteText;
                for (String str : ScoreBoardTexts) {
                    if (str.equals(ChangeTextTo)) {
                        ChangeTextTo = String.format("%s%s", ChangeTextTo, " ");
                    }
                }
                return ChangeTextTo;
            }
        }
        return text;
    }

    private class reserved_word {
        String ReservableText;
        String SubstituteText;

        public reserved_word(String reservableText, String substituteText) {
            ReservableText = reservableText;
            SubstituteText = substituteText;
        }
    }
    //endregion
}
