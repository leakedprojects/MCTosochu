package tokyo.tosochu.scoreboarder.scoreboarder;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Score;
import tokyo.tosochu.scoreboarder.scoreboarder.Classes.PlayerScoreBoardMgr;
import tokyo.tosochu.scoreboarder.scoreboarder.Classes.ScoreboardMgr;

import java.util.ArrayList;
import java.util.List;

public final class ScoreBoarder extends JavaPlugin implements Listener {

    //コンソールで最初に表示されるやつ
    public static final String PluginPrefixOnConsole = "[ScoreBoarder] ";
    //プラグインのインスタンス
    public static ScoreBoarder PluginInstance;
    //config
    public FileConfiguration config;
    //スコアボードのやつ
    public ScoreBoard_main ScoreBoardMain;
    public String DefaultScoreboard="default";
    public boolean PersonalMode=false;

    public List<PlayerScoreBoardMgr> PlayerScoreboards=new ArrayList<>();
    @Override
    public void onEnable() {
        // Plugin startup logic
        PluginInstance = this;
        getCommand("scoreboarder").setExecutor(new Commands());
        ScoreBoardMain = new ScoreBoard_main();
        getServer().getPluginManager().registerEvents(this, this);
        //ファイルないなら出力する
        saveDefaultConfig();
        //configの取得
        config = getConfig();
        LoadConfig();
        System.out.printf("%sPlugin has been Enabled!\n",PluginPrefixOnConsole);
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
        System.out.printf("%sPlugin has been Disabled!\\n",PluginPrefixOnConsole);
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent e)
    {
        PlayerScoreBoardMgr psb=new PlayerScoreBoardMgr(e.getPlayer());
        int count=ScoreBoardMain.ScoreBoards.size();
        if(!DefaultScoreboard.equals("-1"))
        {
            psb.ShowScoreBoard(DefaultScoreboard);
        }
        PlayerScoreboards.add(psb);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        for (PlayerScoreBoardMgr psb:PlayerScoreboards
             ) {
            if(event.getPlayer().getName().equalsIgnoreCase(psb.getPlayerName())){
                PlayerScoreboards.remove(PlayerScoreboards.indexOf(psb));
            }
        }
    }

    public void LoadConfig()
    {
        String ReturnStr=config.getString("DefaultScoreboard","NO_VALUE");
        if(ReturnStr.equals("NO_VALUE")){
            Bukkit.getLogger().info(PluginPrefixOnConsole+"DefaultScoreboard is not set. Setting it default.");
            config.set("DefaultScoreboard","default");
        }else{
            DefaultScoreboard=ReturnStr;
        }

        ReturnStr = config.getString("PersonalMode","NO_VALUE");
        if(ReturnStr.equals("true"))
        {
            PersonalMode=true;
        }else if(ReturnStr.equals("false")) {
            PersonalMode=false;
        }else{
            config.set("PersonalMode","false");
        }

        //スコアボード読み込み
        ScoreBoardMain.LoadScoreboardFromConfig();
        saveConfig();
    }

    public void ReloadConfig(){
        ScoreBoardMain.AllDelete();
        ScoreBoardMain = new ScoreBoard_main();
        reloadConfig();
        config = getConfig();
        LoadConfig();
    }
}
