package tokyo.tosochu.niko.xraymeasure;

public class WorldConfig {
    public String WorldName;
    private boolean EnablePlugin=true;
    private boolean Seted=false;
    WorldConfig(String Name){
        WorldName=Name;
    }

    public void ChangeWorldEnable(boolean Set){
        Seted = true;
        EnablePlugin=Set;
    }

    public boolean IsEnabled(){
        return EnablePlugin;
    }

    public boolean IsSeted(){
        return Seted;
    }
}
