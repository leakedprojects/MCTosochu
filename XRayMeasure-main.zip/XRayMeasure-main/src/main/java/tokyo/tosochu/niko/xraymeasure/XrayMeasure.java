package tokyo.tosochu.niko.xraymeasure;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.event.Listener;
import org.bukkit.scheduler.BukkitScheduler;
import java.util.*;
import java.util.logging.Logger;

public final class XrayMeasure extends JavaPlugin implements Listener {
    public boolean InStatistics = false;
    public int Seconds = -2;
    public Date EndDate;
    public CommandSender StatisticsStarter;
    public long[] StatisticsBlocks;
    public static XrayMeasure PluginInstance;
    public static String PluginPrefixOnConsole="[XRayMeasure]";
    public int JudgeDistance;
    public boolean HighAccuracy=false;
    public List<WorldConfig> WorldsConfigure = new ArrayList<WorldConfig>();
    public List<Material> TransparentBlocks= new ArrayList<>(Arrays.asList
            (
                    Material.AIR,
                    Material.WATER,
                    Material.GLASS,
                    Material.STAINED_GLASS,
                    Material.STAINED_GLASS_PANE,
                    Material.SIGN,
                    Material.WALL_SIGN,
                    Material.WALL_BANNER,
                    Material.FENCE,
                    Material.PAINTING,
                    Material.TRAP_DOOR,
                    Material.ACACIA_DOOR,
                    Material.BIRCH_DOOR,
                    Material.DARK_OAK_DOOR,
                    Material.IRON_DOOR,
                    Material.IRON_DOOR_BLOCK,
                    Material.JUNGLE_DOOR,
                    Material.SPRUCE_DOOR,
                    Material.WOOD_DOOR,
                    Material.WOODEN_DOOR,
                    Material.TORCH,
                    Material.FLOWER_POT,
                    Material.CHORUS_FLOWER,
                    Material.GRASS,
                    Material.YELLOW_FLOWER,
                    Material.REDSTONE_WIRE,
                    Material.BED_BLOCK,
                    Material.CARPET,
                    Material.LEAVES,
                    Material.COBBLESTONE_STAIRS,
                    Material.WOOD_STAIRS,
                    Material.SANDSTONE_STAIRS,
                    Material.BARRIER,
                    Material.END_ROD,
                    Material.IRON_FENCE,
                    Material.LADDER,
                    Material.LEAVES_2
            ));

    @Override
    public void onEnable()
    {
        LoadConfig();

        PluginInstance = this;
        // Plugin startup logic
        BukkitScheduler scheduler = Bukkit.getServer().getScheduler();
        getServer().getPluginManager().registerEvents(this, this);
        scheduler.scheduleSyncRepeatingTask(this,(Runnable) new EveryTickMethod(),1L,1L);
        getCommand("xraymeasure").setExecutor(new Commands());
        System.out.printf("%s XRayMeasure has been enabled!\n",PluginPrefixOnConsole);
    }
    
    @Override
    public void onDisable()
    {
        List<Player> list = new ArrayList<>(Bukkit.getOnlinePlayers());
        for(Player p1: list)
        {
            for (Player p2: list)
            {
                p1.showPlayer(PluginInstance,p2);
            }
        }
    }   
        
    public void LoadConfig(){
        Logger log = Bukkit.getLogger();
        System.out.println("[XRayMeasure] Loading Config Data...");
        saveDefaultConfig();
        reloadConfig();
        FileConfiguration config = getConfig();

        //Judge Distance---------------------------
        int ReturnValue = config.getInt("JudgeDistance",-2);
        if(ReturnValue == -2){
            System.out.printf("%s JudgeDistance has not set. I'll set it as 150.\n",PluginPrefixOnConsole);
            config.set("JudgeDistance","150");
            System.out.printf("%s Saving value of JudgeDistance...\n",PluginPrefixOnConsole);
            JudgeDistance=150;
            saveConfig();
        }else{
            JudgeDistance=ReturnValue;
        }

        //Transparent Blocks -----------------------
        List<String> ReturnListStr;
        ReturnListStr = (List<String>) config.getList("TransparentBlocks");

        if(ReturnListStr == null)
        {
            List<String> blocksListStr=new ArrayList<String>();
            for (Material mat: TransparentBlocks
            ) {
                blocksListStr.add(mat.name());
            }
            config.set("TransparentBlocks",blocksListStr);

            System.out.printf("%s Saving TransparentBlocks...\n",PluginPrefixOnConsole);
            saveConfig();
            log.warning(PluginPrefixOnConsole + "TransparentBlocks has not set. I'll set it as default.");
        }else{
            this.TransparentBlocks.clear();
            for (String item: ReturnListStr)
            {
                this.TransparentBlocks.add(Material.getMaterial(item));
            }
            System.out.printf("%s Successful to load TransparentBlocks!\n",PluginPrefixOnConsole);
        }

        //Worlds-------------------------------------
        List<World> Worlds = getServer().getWorlds();

        for(World world: Worlds){
            WorldsConfigure.add(new WorldConfig(world.getName()));
        }
        int worldCount=WorldsConfigure.size();
        for (int i=0;i!=worldCount;i++) {
            String worldString = config.getString("Worlds." + WorldsConfigure.get(i).WorldName,"NO_WORLD");
            if(worldString.equals("NO_WORLD")){
                System.out.printf("%s Saving WorldConfig...\n",PluginPrefixOnConsole);
                config.set("Worlds."+WorldsConfigure.get(i).WorldName,"true");
                log.warning(PluginPrefixOnConsole+" World \"" + WorldsConfigure.get(i).WorldName + "\" was not found!");
                saveConfig();
                continue;
            }
            WorldsConfigure.get(i).ChangeWorldEnable(Boolean.parseBoolean(worldString));

        }

        //Accuracy-------------------------------------
        String ReturnStr=config.getString("HighAccuracy","NO_VALUE");
        if(ReturnStr.equals("NO_VALUE")){
            config.set("HighAccuracy", "false");
            saveConfig();
        }else{
            if(ReturnStr.equals("true"))
            {
                HighAccuracy= true;
            }else
            {
                HighAccuracy=false;
            }
            System.out.printf("%s High Accuracy mode is now \"%s\" .\n",PluginPrefixOnConsole,String.valueOf(HighAccuracy));
        }


        System.out.printf("%s Successful to load Configs!\n",PluginPrefixOnConsole);
    }
    public void SaveConfig()
    {
        FileConfiguration config = getConfig();
        config.set("JudgeDistance",JudgeDistance);
        List<String> blocksListStr=new ArrayList<String>();
        for (Material mat: TransparentBlocks
        ) {
            blocksListStr.add(mat.name());
        }
        config.set("TransparentBlocks",blocksListStr);
        config.set("HighAccuracy", PluginInstance.HighAccuracy);
        saveConfig();
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
        System.out.printf("%s XRayMeasure has been disabled!\n", PluginPrefixOnConsole);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event)
    {

    }

    @EventHandler
    public void onLeft(PlayerQuitEvent event){
    }



}
