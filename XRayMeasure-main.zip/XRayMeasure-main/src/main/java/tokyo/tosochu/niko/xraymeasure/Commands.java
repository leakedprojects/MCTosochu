package tokyo.tosochu.niko.xraymeasure;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;

import java.util.Calendar;

import static java.util.Arrays.fill;
import static tokyo.tosochu.niko.xraymeasure.XrayMeasure.PluginInstance;
import static tokyo.tosochu.niko.xraymeasure.XrayMeasure.PluginPrefixOnConsole;


public class Commands implements CommandExecutor
{
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args)
    {
        if(command.getName().equalsIgnoreCase("xraymeasure"))
        {

            if(args.length==0){
                sender.sendMessage(ChatColor.GREEN + "===========<XRay Measure>=========");
                sender.sendMessage(ChatColor.GREEN + " Version: "+PluginInstance.getDescription().getVersion());
                sender.sendMessage(ChatColor.GREEN + " Author: "+ChatColor.GOLD+"Nikochan               "+ChatColor.GREEN);
                sender.sendMessage(ChatColor.GREEN + " "+ChatColor.GOLD+"/xraymeasure help" + ChatColor.GREEN + " to show help");
                sender.sendMessage(ChatColor.GREEN + "==================================");
                return true;
            }else {
                switch (args[0]) {
                    case "help":
                        sender.sendMessage(ChatColor.GREEN +"================<XRay Measure>==============" );
                        sender.sendMessage(ChatColor.GREEN +"/xraymeasure ");
                        sender.sendMessage(ChatColor.GREEN+"  "+ChatColor.GOLD+"help: "+ChatColor.GREEN+"Show this message");
                        sender.sendMessage(ChatColor.GREEN+"  "+ChatColor.GOLD+"reload: "+ChatColor.GREEN+"Reload config");
                        sender.sendMessage(ChatColor.GREEN+"  "+ChatColor.GOLD+"changeaccuracy: "+ChatColor.GREEN+"Change XRay Judge accuracy");
                        sender.sendMessage(ChatColor.GREEN+"  "+ChatColor.GOLD+"statistics: "+ChatColor.GREEN+"Take statistics of blocks");
                        sender.sendMessage(ChatColor.GREEN+"============================================");
                        return true;
                    case "reload":
                        PluginInstance.LoadConfig();
                        return true;
                    case "accuracy":
                    case "changeaccuracy":
                        if(args.length!=2) {
                            if (PluginInstance.HighAccuracy) {
                                sender.sendMessage(ChatColor.GREEN + PluginPrefixOnConsole + " Accuracy is now "+ChatColor.GOLD+"High Accuracy "+ChatColor.GREEN+"Mode");
                            }else{

                                sender.sendMessage(ChatColor.GREEN + PluginPrefixOnConsole + " Accuracy is now "+ChatColor.GOLD+"Low Accuracy "+ChatColor.GREEN+"Mode");
                            }
                            return true;
                        }else{
                            switch (args[1]){
                                case "high":
                                    PluginInstance.HighAccuracy=true;

                                    PluginInstance.SaveConfig();
                                    sender.sendMessage(ChatColor.GREEN + PluginPrefixOnConsole + " Accuracy is now changed to "+ChatColor.GOLD+"High Accuracy "+ChatColor.GREEN+"Mode");
                                    return true;

                                case "low":
                                    PluginInstance.HighAccuracy=false;
                                    PluginInstance.SaveConfig();
                                    sender.sendMessage(ChatColor.GREEN + PluginPrefixOnConsole + " Accuracy is now changed to "+ChatColor.GOLD+"Low Accuracy "+ChatColor.GREEN+"Mode");
                                    return true;
                                default:

                                    sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + " Incorrect usage!"+ ChatColor.GREEN+" Correct one is /xraymeasure changeaccuracy [high/low]");
                                    return false;
                            }
                        }

                    case "statistics":
                        if(PluginInstance.InStatistics){
                            sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole+" I'm sorry, but statistics is currently in progress...");
                            return false;
                        }
                        if(args.length<=1){
                            sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole + " Incorrect usage!"+ ChatColor.GREEN+" Correct one is /xraymeasure statics [seconds]");
                        }else{
                            if(isNumber(args[1]))
                            {
                                sender.sendMessage(ChatColor.GREEN +PluginPrefixOnConsole + " Starting statistics for " + args[1] + "seconds...");
                                if(!sender.getName().equals("CONSOLE"))
                                {
                                    System.out.printf("%s %s started statistics for %s seconds...\n",PluginPrefixOnConsole,sender.getName(),args[1]);
                                }
                                PluginInstance.Seconds=Integer.parseInt(args[1]);
                                Calendar cdr = Calendar.getInstance();
                                cdr.add(Calendar.SECOND,PluginInstance.Seconds);
                                PluginInstance.EndDate = cdr.getTime();
                                PluginInstance.StatisticsBlocks = new long[PluginInstance.TransparentBlocks.size()];
                                fill(PluginInstance.StatisticsBlocks,0);
                                PluginInstance.StatisticsStarter=sender;

                                PluginInstance.InStatistics=true;
                                return true;
                            }else{
                                sender.sendMessage(ChatColor.RED + PluginPrefixOnConsole+" "+args[1]+" is not integer!");
                            }
                        }


                        return false;

                    default:
                        sender.sendMessage(PluginPrefixOnConsole+ChatColor.RED+"This command does not exist. "+ChatColor.GREEN+"/xraymeasure help to show help.");
                }
            }

        }

        return false;
    }

    private boolean isNumber(String val) {
        try {
            Integer.parseInt(val);
            return true;
        } catch (NumberFormatException nfex) {
            return false;
        }
    }
}
