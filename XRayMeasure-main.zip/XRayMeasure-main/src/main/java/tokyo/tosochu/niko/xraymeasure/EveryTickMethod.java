package tokyo.tosochu.niko.xraymeasure;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import javax.security.auth.Subject;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static java.util.Arrays.sort;
import static tokyo.tosochu.niko.xraymeasure.XrayMeasure.PluginInstance;
import static tokyo.tosochu.niko.xraymeasure.XrayMeasure.PluginPrefixOnConsole;


public class EveryTickMethod extends BukkitRunnable implements Runnable
{
    final double PlayerHeight=1.73;
    final double PlayerBottom=0.0625;
    final double PlayerMiddle=0.8;
    final double PlayerWidth = 0.3;

    @Override
    public void run()
    {
        if(PluginInstance.InStatistics){
            try {
                StatisticsCheck();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        XRayChecking();
    }

    private void XRayChecking()
    {
        List<Player> Players = (List<Player>) Bukkit.getOnlinePlayers();
        int PlayerCount = Players.size();

        for (int i = 0; i != PlayerCount; i++)
        {
            World PerspectivePlayerWorld = Players.get(i).getWorld();
            String PerspectivePlayerWorldName=PerspectivePlayerWorld.getName();
            boolean disabledOnWorld=false;
            for (WorldConfig cfg: PluginInstance.WorldsConfigure
            ) {
                if(cfg.WorldName.equals(PerspectivePlayerWorldName)){
                    if(!cfg.IsEnabled()){
                        disabledOnWorld=true;
                    }
                }
            }
            if(disabledOnWorld){
                continue;
            }
            Location PerspectivePlayerLocation = Players.get(i).getLocation().add(0,1.625,0);
            for (int j = 0; j != PlayerCount; j++) {
                if (i == j) { //same player
                    continue;
                }

                World SubjectPlayerWorld = Players.get(j).getWorld();
                if (PerspectivePlayerWorld != SubjectPlayerWorld) { //not same world
                    continue;
                }
                Location SubjectPlayerLocation = Players.get(j).getLocation();

                if (PerspectivePlayerLocation.distance(SubjectPlayerLocation) <= PluginInstance.JudgeDistance) {//checking distance
                    Location SubjectLocation;
                    boolean CanSee=false;
                    if(!PluginInstance.HighAccuracy) {//Low Accuracy
                        Location[] SubjectLocations = new Location[3];

                        SubjectLocations[0] = SubjectPlayerLocation.clone().add(0, PlayerBottom, 0);
                        SubjectLocations[1] = SubjectPlayerLocation.clone().add(0, PlayerMiddle, 0);
                        SubjectLocations[2] = SubjectPlayerLocation.clone().add(0, PlayerHeight, 0);
                        for (int k = 0; k != 3; k++) {
                            if (!checkIfBlocksOnVector(PerspectivePlayerLocation, SubjectLocations[k])) {
                                CanSee = true;
                                break;
                            }
                        }
                    }else {//High Accuracy
                        Location[] SubjectLocations = new Location[9];
                        SubjectLocations[0] = SubjectPlayerLocation.clone().add(-PlayerWidth, PlayerBottom, -PlayerWidth);
                        SubjectLocations[1] = SubjectPlayerLocation.clone().add(-PlayerWidth, PlayerBottom, PlayerWidth);
                        SubjectLocations[2] = SubjectPlayerLocation.clone().add(PlayerWidth, PlayerBottom, -PlayerWidth);
                        SubjectLocations[3] = SubjectPlayerLocation.clone().add(PlayerWidth, PlayerBottom, PlayerWidth);
                        SubjectLocations[4] = SubjectPlayerLocation.clone().add(0, PlayerMiddle, 0);
                        SubjectLocations[5] = SubjectPlayerLocation.clone().add(-PlayerWidth, PlayerHeight, -PlayerWidth);
                        SubjectLocations[6] = SubjectPlayerLocation.clone().add(-PlayerWidth, PlayerHeight, PlayerWidth);
                        SubjectLocations[7] = SubjectPlayerLocation.clone().add(PlayerWidth, PlayerHeight, -PlayerWidth);
                        SubjectLocations[8] = SubjectPlayerLocation.clone().add(PlayerWidth, PlayerHeight, PlayerWidth);
                        for (int k = 0; k != 9; k++) {
                            if (!checkIfBlocksOnVector(PerspectivePlayerLocation, SubjectLocations[k])) {
                                CanSee = true;
                                break;
                            }
                        }
                    }

                    if(CanSee){
                        Players.get(j).showPlayer(PluginInstance, Players.get(i));
                    }else{

                        Players.get(j).hidePlayer(PluginInstance, Players.get(i));
                    }


                } else {
                    Players.get(j).hidePlayer(PluginInstance, Players.get(i));
                    continue;
                }


            }
        }
    }

    private void StatisticsCheck() throws IOException {
        Calendar calender = Calendar.getInstance();
        Date date=calender.getTime();
        if(!date.before(PluginInstance.EndDate))
        {//End Statistics
            PluginInstance.InStatistics=false;
            sendMessageCommandSenderAndConsole(PluginInstance.StatisticsStarter,ChatColor.GREEN + PluginPrefixOnConsole+" Statistics has ended! Exporting result to statistics.yml...");
            //aggregate

            StatisticsResults[] Results = new StatisticsResults[PluginInstance.TransparentBlocks.size()];

            int count =Results.length;

            for(int i=0;i!=count;i++)
            {
                Results[i]=new StatisticsResults(PluginInstance.TransparentBlocks.get(i).name(),PluginInstance.StatisticsBlocks[i]);
            }
            Arrays.sort( Results, (a, b)->
            {
                long l = a.Result - b.Result;
                if(l > 0)
                {
                    return -1;
                }else{
                    return 1;
                }
            });

            //Export
            File file = new File(PluginInstance.getDataFolder()+File.separator+"statistics.yml");
            if (!file.exists()) {
                sendMessageCommandSenderAndConsole(PluginInstance.StatisticsStarter,ChatColor.GREEN+PluginPrefixOnConsole+" Creating file...");
                try
                {
                    if(file.createNewFile()) //This needs a try catch
                    {
                        sendMessageCommandSenderAndConsole(PluginInstance.StatisticsStarter,ChatColor.GREEN+PluginPrefixOnConsole+" Successful to create a file!");
                    }else{
                        sendMessageCommandSenderAndConsole(PluginInstance.StatisticsStarter,ChatColor.RED+PluginPrefixOnConsole+" Failed to create a new file!");
                    }

                }
                catch (IOException exc)
                {
                    sendMessageCommandSenderAndConsole(PluginInstance.StatisticsStarter,ChatColor.DARK_RED+PluginPrefixOnConsole+" An exception has been detected! see console...");
                }
            }
            FileConfiguration export = YamlConfiguration.loadConfiguration(file);

            for(StatisticsResults result: Results)
            {
                export.set("StatisticsResult."+result.Name,result.Result);
            }
            export.save(file);

            sendMessageCommandSenderAndConsole(PluginInstance.StatisticsStarter,ChatColor.GREEN + PluginPrefixOnConsole+" Complete!");

        }
    }

    private class StatisticsResults
    {
        public String Name;
        public long Result;

        public StatisticsResults(String name,long result){
            Name=name;
            Result=result;
        }
    }

    private static void sendMessageCommandSenderAndConsole(CommandSender sender,String Text)
    {
        sender.sendMessage(Text);
        if(sender.getName().equals("CONSOLE"))
        {
            System.out.println(Text+"\n");
        }
    }

    private static boolean checkIfBlocksOnVector(Location a, Location b) {
        //A to B
        Vector v = b.toVector().subtract(a.toVector());
        double j = Math.floor(v.length());
        v.multiply(1/v.length()); //Converting v to a unit vector
        for (int i = 0; i<=j; i++) {
            v = b.toVector().subtract(a.toVector());
            v.multiply(1/v.length());
            Block block = a.getWorld().getBlockAt((a.toVector().add(v.multiply(i))).toLocation(a.getWorld()));
            boolean IsTransparentBlock=false;

            int count=PluginInstance.TransparentBlocks.size();
            for (int k=0;k!=count;k++)
            {
                if(block.getType().equals(PluginInstance.TransparentBlocks.get(k)))
                {
                    if(PluginInstance.InStatistics){
                        PluginInstance.StatisticsBlocks[k]++;
                    }
                    IsTransparentBlock=true;
                    break;
                }
            }
            if(!IsTransparentBlock){
                return true;
            }
        }
        return false;
    }

    private static boolean entityBehindPlayer(Entity entity, Player player) {
        Double yaw = 2*Math.PI-Math.PI*player.getLocation().getYaw()/180;
        Vector v = entity.getLocation().toVector().subtract(player.getLocation().toVector());
        Vector r = new Vector(Math.sin(yaw),0, Math.cos(yaw));
        float theta = r.angle(v);
        if (Math.PI/2<theta && theta<3*Math.PI/2) { //Can vary range of theta accordingly (where theta is the angle of this function's 'peripheral' vision)

            return true;
        }
        return false;
    }


}
