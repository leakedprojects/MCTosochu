import { config } from 'dotenv';
import type { Collection} from 'mongodb';
import { MongoClient } from 'mongodb';
import { Record, String } from 'runtypes';
import { CloudRunLogger } from './cloudRunLogger';
import { isProduction } from './isProduction';
import type { BalanceRecord } from './schema/records';


const credentialType = Record({
  username: String,
  password: String,
  uri: String,
});

export const mongodb: Promise<MongoDBInstance> = (async () => {
  config();
  const credentialString = process.env.MONGODB;
  if(credentialString === undefined) { 
    CloudRunLogger.log('ERROR', 'Database Service', 'Put credential to process.env.MONGODB!');
    process.exit(1);
  }
  const credential = JSON.parse(credentialString);
  if(!credentialType.guard(credential)) {
    CloudRunLogger.log('ERROR', 'Database Service', 'Credential(process.env.MONGODB) must be contained the field: username, password, uri!');
    process.exit(1);
  }
  
  const client = await MongoClient.connect(`mongodb+srv://${credential.username}:${credential.password}@${credential.uri}`, {
    authSource: 'admin',
    appName: 'Tosochu-MC-HttpAPI',
    w: 'majority',
    retryWrites: true,
  });

  CloudRunLogger.log('INFO', 'Database Service', 'MongoDB Connected!');
  return new MongoDBInstance(client);

})();

class MongoDBInstance {

  private dbName = isProduction() ? 'production' : 'development';

  public balance: Collection<BalanceRecord>;

  
  constructor( public client: MongoClient ) {
    this.balance = this.client.db(this.dbName).collection<BalanceRecord>('balance');
  }
}
