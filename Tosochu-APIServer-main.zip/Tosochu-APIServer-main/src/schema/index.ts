import { Boolean, String, Number, Null, Union } from 'runtypes';
import { generateAPISchema } from 'typed-http-api';

export const apiSchema = generateAPISchema({
  'POST /userdata/balance/fetch': {
    request: {
      secret: String,
      uuid: String,
      name: String,
    },
    response: {
      success: Boolean,
      balance: Union(Number, Null),
    },
  },
  'POST /userdata/balance/increment': {
    request: {
      secret: String,
      uuid: String,
      name: String,
      amount: Number,
    },
    response: { 
      success: Boolean,
    },
  },
});

export type APISchemaType = typeof apiSchema;
