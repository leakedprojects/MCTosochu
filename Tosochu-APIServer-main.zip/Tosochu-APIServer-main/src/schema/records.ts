export interface BalanceRecord {
  uuid: string;
  name: string;
  balance: number;
}
