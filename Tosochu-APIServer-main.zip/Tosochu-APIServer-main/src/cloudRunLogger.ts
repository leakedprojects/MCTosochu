type Severity = 'DEBUG' | 'INFO' | 'WARNING' | 'ERROR' | 'ALERT'

type Payload = { [key: string]: unknown }

/**StackDriver LoggingのJSON形式でログを吐き出します。 */
export class CloudRunLogger {
  static deserializeLog(severity: Severity, role: string, message: string, payload?: Payload) {
    const entry = {
      severity,
      role,
      message,
      ...payload ?? {},
    };
    return JSON.stringify(entry);
  }
  static log(severity: Severity, role: string, message: string, payload?: Payload) {
    console.log(this.deserializeLog(severity, role, message, payload));
  }
}
