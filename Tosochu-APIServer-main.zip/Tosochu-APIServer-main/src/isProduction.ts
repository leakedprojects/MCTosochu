
export function isProduction() {
  return process.env.PRODUCTION?.toUpperCase() === 'TRUE';
}
