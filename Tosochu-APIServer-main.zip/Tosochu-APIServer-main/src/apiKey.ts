import { CloudRunLogger } from './cloudRunLogger';


export const apiKey = process.env.API_KEY;

if(apiKey === undefined) { 
  CloudRunLogger.log('ERROR', 'KVS Service', 'Put API Key to process.env.API_KEY!');
  process.exit(1);
} else {
  CloudRunLogger.log('INFO', 'KVS Service', 'Filtering By API Key...');
}
