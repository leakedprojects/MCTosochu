import { TypedHttpAPIImplements } from 'typed-http-api';
import { apiKey } from '../apiKey';
import { mongodb } from '../mongo';
import type { APISchemaType } from '../schema';
import { apiSchema } from '../schema';

export const balanceRouter = new TypedHttpAPIImplements<APISchemaType>(apiSchema)
  .implement('POST /userdata/balance/fetch', async (req, body) => {
    if(body.secret !== apiKey) return req.response.data({ success: false, balance: null }).code(200);

    const mongo = await mongodb;
    mongo.balance.updateOne({
      uuid: body.uuid,
    }, {
      $setOnInsert: {
        name: body.name,
        balance: 0,
      },
    }, { upsert: true });
  
    const balance = (await mongo.balance.findOne({
      uuid: body.uuid,
    }))?.balance ?? 0;

    return req.response.data({ success: true, balance }).code(200);
  })
  .implement('POST /userdata/balance/increment', async (req, body) => {
    if(body.secret !== apiKey) return req.response.data({ success: false }).code(200);

    const mongo = await mongodb;
    await mongo.balance.updateOne({
      uuid: body.uuid,
    }, {
      $setOnInsert: {
        name: body.name,
      },
      $inc: { balance: body.amount },
    }, { upsert: true });

    return req.response.data({ success: true }).code(200);
  });



