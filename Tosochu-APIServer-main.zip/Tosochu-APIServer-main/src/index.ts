import { config } from 'dotenv';
import type { FastifyInstance, FastifyRequest } from 'fastify';
import fastify from 'fastify';
import { TypedAPIFastify, TypedHttpAPIServer } from 'typed-http-api';
import fastifyCors from '@fastify/cors';
import { isProduction } from './isProduction';
import type { APISchemaType } from './schema';
import { apiSchema } from './schema';
import { mongodb } from './mongo';
import { balanceRouter } from './router/balance';

config();

const server: FastifyInstance = fastify({ logger: !isProduction() });

const apiServer = 
  new TypedHttpAPIServer<APISchemaType, FastifyRequest>(apiSchema)
    .implement(balanceRouter)
    .export();

server.register(
  fastifyCors, { 
    origin: [],
    methods: ['POST'],
    credentials: true,
  },
);

new TypedAPIFastify(apiServer).register(server);


(async () => {
  try {
    await server.listen({ port: Number(process.env.PORT ?? '8080'), host: '0.0.0.0' });
  } catch (err) {
    server.log.error(err);
    process.exit(1);
  }
})();
process.once('SIGTERM', () => {
  (async () => {
    await server.close();
    const mongo = await mongodb;
    await mongo.client.close();
  })();
});
