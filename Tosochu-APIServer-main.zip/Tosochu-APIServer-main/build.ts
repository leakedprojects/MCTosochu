import { mkdir, rm } from 'fs/promises';
import { build } from 'esbuild';

(async () => {

  await rm('dist/', { recursive: true, force: true });
  await mkdir('dist/');
  await build({
    bundle: true,
    minify: true,
    sourcemap: true,
    entryPoints: ['src/index.ts'],
    outdir: 'dist/',
    platform: 'node',
    external: ['bcrypt'],
  });

})();
