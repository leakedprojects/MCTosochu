---
name: Skript-Migration
about: Javaに移行すべきSkriptの機能
title: 'Skript: (Title here)'
labels: Skript-feature
assignees: ''

---

**元のプログラム**
Skriptのファイルパス、リンク、もしくはソースコードそのものを掲載してください。

**考慮点**
Javaに移行する途中で憂慮しなければならない点があれば記入してください。
