package dev.mctosochu.main.tosochumain.util;

import org.bukkit.Location;
import org.bukkit.World;

public class Vec3D {
    public double x;
    public double y;
    public double z;

    public Vec3D(Location l) {
        this.x = l.getX();
        this.y = l.getY();
        this.z = l.getZ();
    }

    public Vec3D(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public Vec3D add(Vec3D vec) {
        return new Vec3D(x + vec.x, y + vec.y, z + vec.z);
    }

    public Vec3D scalarScale(double k) {
        return new Vec3D(x * k, y * k, z * k);
    }

    public Location withWorld(World w) {
        return new Location(w, x, y, z);
    }
    public Location withWorld(World w, float yaw, float pitch) {
        return new Location(w, x, y, z, yaw, pitch);
    }

    public Vec3D normalize() {
        double dist = length();
        return new Vec3D(x / dist, y / dist, z / dist);
    }

    public double length() {
        return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
    }


    public Vec3D lattice() {
        return new Vec3D(Math.floor(x), Math.floor(y), Math.floor(z));
    }

    public static boolean equal(Vec3D a, Vec3D b) {
        if(a.x != b.x) return false;
        if(a.y != b.y) return false;
        return a.z == b.z;
    }
}
