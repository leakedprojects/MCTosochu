package dev.mctosochu.main.tosochumain.mission;

import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.match.Game;
import dev.mctosochu.main.tosochumain.util.DispatchableTimer;
import dev.mctosochu.main.tosochumain.util.Util;
import org.bukkit.ChatColor;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Chest;
import org.bukkit.block.data.Directional;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.Nullable;

public class ItemChallengeMission extends Mission {
    public final Location chestLoc;

    private DispatchableTimer timer;
    private final ItemStack freezingGun = Util.getNamedItemStack(Material.DRAGON_HEAD, Util.getColoredString("冷凍銃", ChatColor.AQUA));

    public ItemChallengeMission(TosochuMain plugin, Game game) {
        super(plugin, game, "station", 1);
        this.chestLoc = new Location(this.game.worldInstance.world, -9, 53, -131);
    }

    @Override
    public void trigger() {
        this.game.missionManager.isMissionRunning = true;

        this.game.runners.forEach(p -> {
            p.sendMessage("\n--------------- MISSION\n" +
                              "地下街のかき氷屋にチェストを設置した\n" +
                              "チェストの中にはハンターを一定時間停止させる\n" +
                              "ことができる冷凍銃を手に入れることができる\n"
            );
        });

        chestLoc.getBlock().setType(Material.CHEST);
        Chest chest = (Chest) chestLoc.getBlock();
        chest.setCustomName("冷蔵庫");
        // TODO: 仮対応、EffectiveItemManagerかなんかから指定したアイテムを取り出せるように
        chest.getBlockInventory().setItem(13, this.freezingGun);
        ((Directional) chest.getBlockData()).setFacing(BlockFace.EAST);

        this.timer = new DispatchableTimer(this.plugin, 180);
        this.timer.schedule(180, () -> this.end(null, false));
    }

    @Override
    protected void end(@Nullable Player player, boolean isSucceed) {
        if (isSucceed && player != null) {
            Util.playEffectPillar(this.chestLoc, Effect.FIREWORK_SHOOT, 1.2, 30);
            player.sendMessage("冷凍銃を手に入れた");
            this.game.runners.stream()
                .filter(p -> !p.equals(player))
                .forEach(p -> {
                    p.sendMessage("\n--------------- MAIL\n" +
                                      "ミッション成功：\n" +
                                      player.getName() + " さんが冷凍銃を手に入れた。\n"
                    );
                });
        }
        this.chestLoc.getBlock().setType(Material.AIR);
        this.timer.cancel();
    }

    @EventHandler
    public void onMoveItem(InventoryMoveItemEvent e) {
        if (e.getSource().getLocation() == null || !e.getSource().getLocation().equals(this.chestLoc)) return;
        if (e.getDestination().getViewers().size() != 1 && !(e.getDestination().getViewers().get(0) instanceof Player)) return;
        if (e.getItem().isSimilar(this.freezingGun))
            this.end((Player) e.getDestination().getViewers().get(0), true);
    }

    @EventHandler
    public void onDragItem(InventoryDragEvent e) {
        if (e.getInventory().getLocation() == null || !e.getInventory().getLocation().equals(this.chestLoc) || !(e.getWhoClicked() instanceof Player)) return;
        if (e.getOldCursor().isSimilar(this.freezingGun))
            this.end((Player) e.getWhoClicked(), true);
    }
}
