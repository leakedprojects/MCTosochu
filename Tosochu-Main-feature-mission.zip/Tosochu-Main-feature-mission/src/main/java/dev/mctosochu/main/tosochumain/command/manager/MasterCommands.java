package dev.mctosochu.main.tosochumain.command.manager;

import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.command.DeveloperCommands;
import dev.mctosochu.main.tosochumain.command.MatchCommands;
import dev.mctosochu.main.tosochumain.command.ReloadCommand;
import dev.mctosochu.main.tosochumain.command.WannaSwitchSpectate;

public class MasterCommands {
    TosochuMain plugin;

    MatchCommands matchCommands;
    WannaSwitchSpectate wannaSwitchSpectate;

    ReloadCommand reloadCommand;
    DeveloperCommands developerCommands;

    public MasterCommands(TosochuMain plugin) {
        this.plugin = plugin;
        this.matchCommands = new MatchCommands(plugin, plugin.commandManager, plugin.selectMatchStrategy);
        this.wannaSwitchSpectate = new WannaSwitchSpectate(plugin);
        this.reloadCommand = new ReloadCommand(plugin, plugin.commandManager);
        this.developerCommands = new DeveloperCommands(plugin, plugin.commandManager);
    }
}
