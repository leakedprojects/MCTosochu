package dev.mctosochu.main.tosochumain.util;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import dev.mctosochu.main.tosochumain.TosochuMain;
import org.apache.commons.codec.binary.Base64;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class Util {
    public static ItemStack getNamedItemStack(Material material, String name) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(name);
        stack.setItemMeta(meta);
        return stack;
    }

    public static String getColoredString(String value, ChatColor... colors) {
        StringBuilder builder = new StringBuilder();
        Arrays.stream(colors).forEach(v -> builder.append(v.toString()));
        return builder.append(value).toString();
    }

    //seekerがtargetのことを見えるようにしたり、見えなくしたりする
    public static void setVisibility(boolean visible, Player seeker, Player target, TosochuMain plugin) {
        if(visible) {
            seeker.showPlayer(plugin, target);
        } else {
            seeker.hidePlayer(plugin, target);
        }
    }

    public static ItemStack getColoredPotion(String name, PotionType type, Color color) {
        String typeString = type == PotionType.NORMAL ? "" : type.toString() + "_";
        ItemStack potion = new ItemStack(Material.valueOf(typeString + "POTION"));
        PotionMeta meta = (PotionMeta) potion.getItemMeta();
        meta.setDisplayName(name);
        meta.setColor(color);
        potion.setItemMeta(meta);
        return potion;
    }

    public static ItemStack getPlayerHead(Player player) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) head.getItemMeta();
        meta.setOwningPlayer(player);
        head.setItemMeta(meta);
        return head;
    }

    public static ItemStack getCustomHead(String url, String name) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        if (url.isEmpty()) return head;

        SkullMeta meta = (SkullMeta) head.getItemMeta();
        meta.setDisplayName(name);
        GameProfile profile = new GameProfile(UUID.randomUUID(), null);

        byte[] encodedData = Base64.encodeBase64(String.format("{textures:{SKIN:{url:\"%s\"}}}", url).getBytes());
        profile.getProperties().put("textures", new Property("textures", new String(encodedData)));

        Field profileField;
        try {
            profileField = meta.getClass().getDeclaredField("profile");
            profileField.setAccessible(true);
            profileField.set(meta, profile);
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
            e.printStackTrace();
        }

        head.setItemMeta(meta);
        return head;
    }

    public static String stylingCurrency(int amount) {
        DecimalFormat byThree = new DecimalFormat("###,###");
        return byThree.format(amount) + "円";
    }

    public static List<PlayerPair> getPlayerPair(List<Player> players) {
        if (players.isEmpty()) return Collections.emptyList();
        List<PlayerPair> list = new ArrayList<>();
        players.forEach(p1 ->
            players.stream()
                .filter(p2 -> !p2.equals(p1))
                .filter(p2 -> !list.contains(new PlayerPair(p2, p1)))
                .forEach(p2 -> list.add(new PlayerPair(p1, p2))));
        return list;
    }
    public static void playEffectPillar(Location centerLoc, Effect effect, double space, int loop) {
        if (!isCenter(centerLoc))
            centerLoc.add(0.5, 0, 0.5);
        Location startLoc = centerLoc.add(0, 0.5, 0);
        double count = 0;
        for (int i = 0; i < 360; i+=3) {
            if (count == loop) break;
            double rad = Math.toRadians(i);
            startLoc.getWorld().playEffect(new Location(startLoc.getWorld(),
                                                        startLoc.getX() + Math.cos(rad) * space,
                                                        startLoc.getY() + (count / 10),
                                                        startLoc.getZ() + Math.sin(rad) * space
                                           ), effect, 0);
            count++;
        }
    }

    public static boolean isCenter(Location loc) {
        return String.valueOf(loc.getX()).endsWith("0.5") && String.valueOf(loc.getZ()).endsWith("0.5");
    }

    public static class PlayerPair {
        public Player p1;
        public Player p2;
        public PlayerPair(Player p1, Player p2) {
            this.p1 = p1;
            this.p2 = p2;
        }
    }

    public enum PotionType {
        NORMAL,
        SPLASH,
        LINGERING
    }
}
