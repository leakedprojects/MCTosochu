package dev.mctosochu.main.tosochumain.mission;

import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.match.Game;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.jetbrains.annotations.Nullable;

public abstract class Mission implements Listener {
    protected final TosochuMain plugin;
    protected final Game game;
    protected final String worldName;
    protected final int minimumRequirePlayers;

    public Mission(TosochuMain plugin, Game game, String worldName, int minimumRequirePlayers) {
        this.plugin = plugin;
        this.game = game;
        this.worldName = worldName;
        this.minimumRequirePlayers = minimumRequirePlayers;
        this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
    }

    public abstract void trigger();
    protected abstract void end(@Nullable Player player, boolean isSucceed);
}
