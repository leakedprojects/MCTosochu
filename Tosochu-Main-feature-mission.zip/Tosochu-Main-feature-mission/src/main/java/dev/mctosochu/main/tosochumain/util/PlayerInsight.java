package dev.mctosochu.main.tosochumain.util;


import org.bukkit.Location;
import org.bukkit.World;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class PlayerInsight {
    Location origin;
    Location target;

    public PlayerInsight(Location origin, Location target) {
        this.origin = origin;
        this.target = target;
    }

    public boolean inSight() {
        if(!this.origin.getWorld().equals(this.target.getWorld())) return false;
        World w = this.origin.getWorld();
        List<Vec3D> originBoundingBox = boundingBox(new Vec3D(origin));
        List<Vec3D> targetBoundingBox = boundingBox(new Vec3D(target));

        List<Ray> ray = originBoundingBox.stream()
            .flatMap(v -> targetBoundingBox.stream().map(t -> new Ray(w, v, t)))
            .collect(Collectors.toList());

        return ray.stream().anyMatch(Ray::reachable);
    }

    public static List<Vec3D> boundingBox(Vec3D v) {
        return new ArrayList<>(Arrays.asList(
            0.05,
            1.0,
            1.95
        )).stream().flatMap(yDiff -> new ArrayList<>(Arrays.asList(
            v.add(new Vec3D(-0.45, yDiff, 0)),
            v.add(new Vec3D(0.45, yDiff, 0)),
            v.add(new Vec3D(0, yDiff, 0.45)),
            v.add(new Vec3D(0, yDiff, -0.45))
        )).stream()).collect(Collectors.toList());
    }

}
