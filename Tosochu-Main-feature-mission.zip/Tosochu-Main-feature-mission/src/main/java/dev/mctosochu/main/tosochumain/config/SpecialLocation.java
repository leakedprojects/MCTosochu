package dev.mctosochu.main.tosochumain.config;

import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.util.Vec3D;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SpecialLocation {
    TosochuMain plugin;

    public World lobbyWorld;
    public World votemapWorld;
    public List<GameMap> gameMaps = new ArrayList<>();

    public Location lobbySpawn;

    public Location getVotemapSpawn(World w) {
        return new Location(w, 0, 4, 0);
    }

    public static World worldLoadAndGet(TosochuMain plugin, String name) {
        World w = plugin.getServer().getWorld(name);
        return w == null ? new WorldCreator(name).createWorld() : w;
    }

    public SpecialLocation(TosochuMain plugin) {
        this.plugin = plugin;
        lobbyWorld = worldLoadAndGet(plugin, "world");
        votemapWorld = worldLoadAndGet(plugin, "votemap");
        lobbySpawn = new Location(this.lobbyWorld, 0, 4, 0);

        gameMaps.add(
            new GameMap(
                "kiminona",
                worldLoadAndGet(plugin, "kiminona"),
                new GameMapLocations(
                    new ArrayList<>(Arrays.asList(
                        new Vec3D(150.5, 4, -175.5),
                        new Vec3D(142.5, 4, -156.5),
                        new Vec3D(138.5, 4, -160.5),
                        new Vec3D(131.5, 4, -183.5),
                        new Vec3D(134.5, 4, -154.5),
                        new Vec3D(124.5, 4, -161.5),
                        new Vec3D(121.5, 4, -183.5),
                        new Vec3D(113.5, 4, -169.5),
                        new Vec3D(110.5, 4, -156.5)
                    )),
                    new ArrayList<>(Arrays.asList(
                        new Vec3D(141.5, 4, -179.5),
                        new Vec3D(122.5, 4, -171.5),
                        new Vec3D(112.5, 4, -162.5)
                    )),
                    new ArrayList<>(),
                    new Vec3D(131.5, 4, -165.5),
                    new Vec3D(140.5, 7, -172.5)
                ),
                "君の名は",
                "kokopy様",
                "https://www.planetminecraft.com/project/-your-name/"
            )
        );
        gameMaps.add(
            new GameMap(
                "station",
                worldLoadAndGet(plugin, "station"),
                new GameMapLocations(
                    new ArrayList<>(Arrays.asList(
                        new Vec3D(47.5, 69, -39.5),
                        new Vec3D(48.5, 69, -39.5),
                        new Vec3D(49.5, 69, -39.5),
                        new Vec3D(47.5, 69, -40.5),
                        new Vec3D(48.5, 69, -40.5),
                        new Vec3D(49.5, 69, -40.5),
                        new Vec3D(47.5, 69, -41.5),
                        new Vec3D(48.5, 69, -41.5),
                        new Vec3D(49.5, 69, -41.5),
                        new Vec3D(47.5, 69, -42.5),
                        new Vec3D(48.5, 69, -42.5),
                        new Vec3D(49.5, 69, -42.5)
                    )),
                    v -> w -> v.withWorld(w, 180f, 0f),
                    new ArrayList<>(Arrays.asList(
                        new Vec3D(48.5, 69, -88.5),
                        new Vec3D(44.5, 69, -88.5),
                        new Vec3D(40.5, 69, -88.5),
                        new Vec3D(36.5, 69, -88.5)
                    )),
                    v -> v::withWorld,
                    new ArrayList<>(Arrays.asList(
                        new Vec3D(48, 70, -88),
                        new Vec3D(48, 69, -88),
                        new Vec3D(44, 70, -88),
                        new Vec3D(44, 69, -88),
                        new Vec3D(40, 70, -88),
                        new Vec3D(40, 69, -88),
                        new Vec3D(36, 70, -88),
                        new Vec3D(36, 69, -88)
                    )),
                    new Vec3D(71, 69, -88),
                    new Vec3D(78, 72, -92)
                ),
                "駅",
                "逃走中 in Minecraft Builders",
                ""
            )
        );
    }

}
