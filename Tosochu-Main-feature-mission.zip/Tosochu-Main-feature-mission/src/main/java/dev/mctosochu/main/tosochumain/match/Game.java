package dev.mctosochu.main.tosochumain.match;

import dev.mctosochu.main.tosochumain.ScoreboardClass.Sidebar;
import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.config.GameMap;
import dev.mctosochu.main.tosochumain.effectiveItem.EffectiveItemManager;
import dev.mctosochu.main.tosochumain.mission.MissionManager;
import dev.mctosochu.main.tosochumain.util.ClickableItem;
import dev.mctosochu.main.tosochumain.util.ClickableItemBuilder;
import dev.mctosochu.main.tosochumain.util.DispatchableTimer;
import dev.mctosochu.main.tosochumain.util.PlayerInsight;
import dev.mctosochu.main.tosochumain.util.Util;
import dev.mctosochu.main.tosochumain.util.Vec3D;
import dev.mctosochu.main.tosochumain.util.WorldInstance;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByBlockEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Game implements Listener {
    public final WorldInstance worldInstance;
    TosochuMain plugin;
    public Match match;
    public GameMap map;
    public MissionManager missionManager;

    public List<Player> hunters;
    public List<Player> runners;
    public List<Player> jailed = new ArrayList<>();
    public Map<Player, ArmorStand> spectators = new HashMap<>();

    //透明化により、視界の有無に関わらず非表示になる
    public List<Player> showBypassPlayers = new ArrayList<>();

    //動けるかどうか
    private boolean movable = false;
    private boolean hunterReleased = false;

    //ゲーム中かどうか
    public boolean inGame = false;

    //ゲーム終了したかどうか
    @Nullable
    public GameEndReason gameFinished = null;

    @Nullable
    BossBar gameLoop;

    @Nullable
    DispatchableTimer gameLoopTimer = null;

    @Nullable
    DispatchableTimer runnerBufferTimer = null;

    //ゲーム時間（秒）
    static final int GAME_LENGTH = 60 * 15;

    //賞金 (1秒あたり)
    static final int PRIZE_PER_SEC = 300;

    //「残り逃走者」として表示させる最大の人数
    static final int REMAINING_RUNNERS_MAX_LIMITATION = 6;

    static final ItemStack HUNTER_HEAD = Util.getCustomHead("https://textures.minecraft.net/texture/1683ee638273d5e62bf3e3562a9b0e94fff876401cf3fbfe1328aa4025fd66b9", "ハンターの頭");
    static final ItemStack RUNNER_CHESTPLATE = new ItemStack(Material.CHAINMAIL_CHESTPLATE);

    Sidebar sidebar = new Sidebar(Util.getColoredString("  逃走中 in Minecraft  ", ChatColor.AQUA, ChatColor.BOLD));


    public Game(TosochuMain plugin, Match match, GameMap map) {
        this.plugin = plugin;
        this.plugin.getServer().getPluginManager().registerEvents(this, plugin);
        this.match = match;
        this.map = map;

        //ハンターを決定
        List<Player> shuffled = new ArrayList<>(this.match.participants);
        Collections.shuffle(shuffled);

        hunters = IntStream.range(0, hunterCount(this.match.participants.size()))
                .mapToObj(shuffled::get)
                .collect(Collectors.toList());

        runners = this.match.participants.stream()
                .filter(p -> !hunters.contains(p))
                .collect(Collectors.toList());

        worldInstance = new WorldInstance(map.world);
        worldInstance.world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        worldInstance.world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        worldInstance.world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        worldInstance.world.setFullTime(6000);
        worldInstance.world.setStorm(false);
        worldInstance.world.setThundering(false);

        //スコアボードとチームの設定
        this.match.participants.forEach(p -> plugin.sidebarMaster.belong(p, sidebar));
        refreshScoreboard();

        //ハンターをハンタースポーン位置のランダムな場所へ飛ばす
        List<Vec3D> hunterSpawns = new ArrayList<>(this.map.locations.HunterSpawnPoints);
        Collections.shuffle(hunterSpawns);

        List<Player> hunterPlayers = this.match.participants.stream()
            .filter(p -> this.hunters.contains(p))
            .peek(p -> TeamBuilder.join(p, match, sidebar))
            .collect(Collectors.toList());

        IntStream.range(0, hunterPlayers.size())
            .forEach(i -> hunterPlayers.get(i)
                .teleport(
                    map.locations.HunterSpawnPointLocator
                        .apply(hunterSpawns.get(i % hunterSpawns.size()))
                        .apply(this.worldInstance.world)
                )
            );

        //逃走者を逃走者スポーン位置のランダムな場所へ飛ばす
        List<Vec3D> runnerSpawns = new ArrayList<>(this.map.locations.RunnerSpawnPoints);
        Collections.shuffle(runnerSpawns);

        List<Player> runnerPlayers = this.match.participants.stream()
            .filter(p -> this.runners.contains(p))
            .peek(p -> TeamBuilder.join(p, match, sidebar))
            .collect(Collectors.toList());

        IntStream.range(0, runnerPlayers.size())
            .forEach(i -> runnerPlayers.get(i)
                .teleport(
                    map.locations.RunnerSpawnPointLocator
                        .apply(runnerSpawns.get(i % runnerSpawns.size()))
                        .apply(this.worldInstance.world)
                )
            );


        //アドベンチャーモード
        this.match.participants.forEach(p -> p.setGameMode(GameMode.ADVENTURE));



        this.match.participants.stream()
            .filter(p -> hunters.contains(p))
            .forEach(p -> p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, Integer.MAX_VALUE, 0, false, false, false)));

        //タイトル表示
        runnerPlayers.forEach(v -> v.sendTitle("あなたは逃走者です。", "制限時間の間ハンターから逃げ続けましょう。", 5, 40, 5));
        hunterPlayers.forEach(v -> v.sendTitle("あなたはハンターです。", "制限時間の間に逃走者を捕えましょう。", 5, 40, 5));

        //Itemクリア
        this.match.participants.forEach(p -> p.getInventory().clear());

        hunterPlayers.stream().map(HumanEntity::getInventory).forEach(i -> i.setHelmet(HUNTER_HEAD));

        runnerPlayers.stream().map(HumanEntity::getInventory).forEach(i -> i.setChestplate(RUNNER_CHESTPLATE));

        //「今回のハンター」を表示
        this.match.participants.stream()
            .peek(v -> v.sendMessage(Util.getColoredString("======", ChatColor.RED)))
            .peek(v -> v.sendMessage(Util.getColoredString("*今回のハンター", ChatColor.RED)))
            .peek(v -> this.match.participants.stream().filter(p -> hunters.contains(p))
                .forEach(p -> v.sendMessage(Util.getColoredString(p.getName(), ChatColor.RED)))
            )
            .forEach(v -> v.sendMessage(Util.getColoredString("======", ChatColor.RED)));

        //カウントダウン
        this.plugin.getServer().getScheduler().runTaskLater(this.plugin,() -> this.match.participants.forEach(p -> {
            p.sendTitle("3", "ゲーム開始まで", 1, 25, 0);
            p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_LAND, 1.0f, 1.0f);
        }), 160L);
        this.plugin.getServer().getScheduler().runTaskLater(this.plugin,() -> this.match.participants.forEach(p -> {
            p.sendTitle("2", "ゲーム開始まで", 0, 25, 0);
            p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_LAND, 1.0f, 1.0f);
        }), 180L);
        this.plugin.getServer().getScheduler().runTaskLater(this.plugin,() -> this.match.participants.forEach(p -> {
            p.sendTitle("1", "ゲーム開始まで", 0, 25, 0);
            p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_LAND, 1.0f, 1.0f);
        }), 200L);
        this.plugin.getServer().getScheduler().runTaskLater(this.plugin,() -> {
            this.match.participants.forEach(p -> {
                p.sendTitle("スタート", "", 0, 40, 5);
                p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_USE, 1.0f, 1.0f);
            });
            this.start();
        }, 220L);
    }

    void refreshScoreboard() {
        sidebar.editAllPlayer(sb -> {
            long jailedCount = match.participants.stream().filter(p -> jailed.contains(p)).count();
            sb.editTexts(new ArrayList<>() {
                {
                    final List<Player> remainingRunners =
                        match.participants.stream().filter(p -> runners.contains(p)).filter(p -> !jailed.contains(p)).collect(Collectors.toList());
                    add("");
                    add(" 残り逃走者:");
                    remainingRunners.stream().limit(REMAINING_RUNNERS_MAX_LIMITATION).forEach(v -> add("   " + v.getName()));
                    if(remainingRunners.size() > REMAINING_RUNNERS_MAX_LIMITATION) {
                        add("   (他" + (remainingRunners.size() - REMAINING_RUNNERS_MAX_LIMITATION) + "名)");
                    }
                    if (jailedCount > 0) {
                        add("");
                        add(" " + jailedCount + "名 確保済み");
                    }
                    add("");
                }
            });
        });
    }

    void refreshActionbar() {
        this.match.participants.forEach(p -> {
            if (!runners.contains(p)) return;
            p.sendActionBar(Util.getColoredString("あなたの賞金: " + Util.stylingCurrency(calcPrize(p)), ChatColor.BOLD));
        });
    }

    int calcPrize(Player p) {
        if(!runners.contains(p)) return 0;

        //捕まればｧ...賞金はｧ...ｾﾞｪｪｪﾛｵｵｵｫｫｫ......;
        if(jailed.contains(p)) return 0;

        //ゲームが始まってなければ0円
        if(!this.movable) return 0;
        if(this.gameFinished != null){
            return this.gameFinished == GameEndReason.TIMEOUT ? GAME_LENGTH * PRIZE_PER_SEC : 0;
        } else {
            if (this.gameLoopTimer == null) return 0;
            return (GAME_LENGTH - gameLoopTimer.remaining.get()) * PRIZE_PER_SEC;
        }
    }

    void start(){
        this.inGame = true;
        this.movable = true;

        this.gameLoop = plugin.getServer().createBossBar("ハンター放出まで: 30秒", BarColor.RED, BarStyle.SOLID);
        this.gameLoop.setProgress(1);
        this.match.participants.forEach(p -> plugin.bossbarMaster.belong(p, this.gameLoop));

        //「牢屋」というベルを表示
        Location jailLabelLoc =
            this.map.locations.jailClosest
                .add(this.map.locations.jailFarthest)
                .scalarScale(0.5)
                .withWorld(this.worldInstance.world);
        ArmorStand jailLabel = worldInstance.world.spawn(jailLabelLoc, ArmorStand.class);
        jailLabel.setInvulnerable(true);
        jailLabel.setMarker(true);
        jailLabel.setGravity(false);
        jailLabel.setCanPickupItems(false);
        jailLabel.setCustomName("牢屋");
        jailLabel.setCustomNameVisible(true);
        jailLabel.setVisible(false);




        this.plugin.getServer().getScheduler().runTaskLater(this.plugin,() -> this.match.participants.forEach(p -> {
            runnerBufferTimer = new DispatchableTimer(plugin, 30);
            runnerBufferTimer.changeRemaining(() -> {
                if(this.gameLoop != null) {
                    this.gameLoop.setTitle("ハンター放出まで: " + runnerBufferTimer.remaining.get() + "秒");
                    this.gameLoop.setProgress(runnerBufferTimer.remaining.get() / 30.0);
                }
                if(0 < this.runnerBufferTimer.remaining.get() && this.runnerBufferTimer.remaining.get() <= 3) {
                    p.sendTitle(Util.getColoredString("*ハンター開放まで" + this.runnerBufferTimer.remaining.get() + "秒", ChatColor.BOLD, ChatColor.RED), "", 0, 25, 0);
                    p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_LAND, 1.0f, 1.0f);
                }
            });
            p.sendTitle(Util.getColoredString("*ハンター開放まで30秒", ChatColor.BOLD, ChatColor.RED), "", 5, 25, 5);
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_SNARE, 1.0f, 1.0f);

            runnerBufferTimer.schedule(10, () -> {
                p.sendTitle(Util.getColoredString("*ハンター開放まで10秒", ChatColor.BOLD, ChatColor.RED), "", 5, 25, 5);
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_SNARE, 1.0f, 1.0f);
            });
            runnerBufferTimer.schedule(0, () -> {
                p.sendTitle(Util.getColoredString("ハンターが開放されました。", ChatColor.BOLD, ChatColor.RED), "", 0, 25, 5);
                p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 1.0f);
                hunterRelease();
            });
        }), 40L);

        checkGameEndCondition();
    }

    public void hunterRelease() {
        hunterReleased = true;
        this.map.locations.ReleaseToBreakBlocks.stream().map(v -> v.withWorld(worldInstance.world)).map(Location::getBlock).forEach(b -> b.setType(Material.AIR));

        //ハンターの盲目解除
        this.match.participants.stream()
            .filter(p -> hunters.contains(p))
            .forEach(p -> p.removePotionEffect(PotionEffectType.BLINDNESS));

        //カウントダウンの表示
        this.gameLoopTimer = new DispatchableTimer(plugin, GAME_LENGTH);
        this.gameLoopTimer.changeRemaining(() -> {
            if(this.gameLoopTimer == null) return;
            if(this.gameLoopTimer.remaining.get() <= 0) return;
            int remainingSeconds = this.gameLoopTimer.remaining.get() % 60;
            int remainingMinutes = (int) Math.floor(this.gameLoopTimer.remaining.get() / 60.0);
            if(this.gameLoop != null) {
                this.gameLoop.setTitle(
                    Util.getColoredString("残り時間 " + remainingMinutes + ":" + String.format("%02d", remainingSeconds), ChatColor.BOLD)
                );
            }

            double remaining = (double)this.gameLoopTimer.remaining.get() / (double)(GAME_LENGTH);
            this.gameLoop.setProgress(Math.max(0, Math.min(remaining, 1)));
            refreshActionbar();
        });
        this.gameLoopTimer.schedule(0, () -> end(GameEndReason.TIMEOUT));

        //アイテムを渡す
        this.match.participants
            .forEach(p ->
                EffectiveItemManager.setup(
                    runners.contains(p) ? plugin.effectiveItemManager.runnerItems : plugin.effectiveItemManager.hunterItems, p
                )
            );

        missionManager = new MissionManager(this.plugin, this, this.gameLoopTimer);
        missionManager.startMissions();
    }

    //ゲームの終了条件を更新
     void checkGameEndCondition() {
        refreshScoreboard();
        if(!this.inGame) return;
        long availableHunters =
            this.match.participants.stream()
                .filter(p -> this.hunters.contains(p))
                .count();
        if(availableHunters < 1) {
            end(GameEndReason.NO_AVAILABLE_HUNTER);
            return;
        }
        long availableRunners =
            this.match.participants.stream()
                .filter(p -> this.runners.contains(p))
                .filter(p -> !this.jailed.contains(p))
                .count();
        if(availableRunners < 1) {
            end(GameEndReason.NO_AVAILABLE_RUNNER);
        }
     }

    public void end(GameEndReason reason) {
        if(this.gameFinished != null) return;
        if(reason == GameEndReason.SERVER_RELOAD) {
            this.match.participants.forEach(p -> p.sendMessage("*サーバーリロードのため強制終了しました。"));
        }
        if(reason == GameEndReason.NO_AVAILABLE_HUNTER) {
            this.match.participants.forEach(p -> p.sendMessage("*ハンターが全員切断したためゲームを終了しました。"));
        }
        this.inGame = false;
        this.gameFinished = reason;
        if(reason != GameEndReason.TIMEOUT && this.gameLoopTimer != null) {
            this.gameLoopTimer.cancel();
            this.gameLoopTimer = null;
        }
        if(this.runnerBufferTimer != null) {
            this.runnerBufferTimer.cancel();
            this.runnerBufferTimer = null;
        }
        if(this.gameLoop != null) {
            this.gameLoop.setTitle("ゲーム終了！");
            this.gameLoop.setProgress(0);
        }
        this.match.participants.forEach(p -> p.sendTitle("ゲーム終了！", "", 10, 40, 10));
        this.match.participants.forEach(p -> p.playSound(p.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1.0f, 1.0f));

        //賞金の精算
        if(reason == GameEndReason.TIMEOUT) {
            this.match.participants.stream()
                .filter(p -> runners.contains(p))
                .filter(p -> !jailed.contains(p))
                .peek(p -> p.sendMessage("賞金" + Util.stylingCurrency(GAME_LENGTH * PRIZE_PER_SEC) + "を獲得しました！"))
                .forEach(p -> plugin.apiServer.balanceIncrement(p, GAME_LENGTH * PRIZE_PER_SEC));
        }

        ClickableItem backToLobby = new ClickableItemBuilder(this.plugin)
            .setMaterial(Material.RED_BED)
            .setName(Util.getColoredString("ロビーへ戻る", ChatColor.RED, ChatColor.BOLD))
            .build()
            .addAction(p -> this.match.leave(p));

        this.match.participants.forEach(p -> p.getInventory().setItem(8, backToLobby.itemStack));

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> this.match.matchGracefulRelease(), 40L);
    }

    void leave(Player p) {
        this.plugin.bossbarMaster.ripAway(p);
    }

    //ハンターの数を決定する
    static int hunterCount(int participants) {
        if(35 <= participants) return 4;
        if(25 <= participants) return 3;
        if(15 <= participants) return 2;
        return 1;
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent e) {
        if(!this.match.participants.contains(e.getPlayer())) return;

        //ネームタグを見えなくする
        if(!this.jailed.contains(e.getPlayer())) {
            this.match.participants.stream().filter(p -> !jailed.contains(p))
                .forEach(p2 -> {
                    boolean inSight = new PlayerInsight(p2.getLocation(), e.getPlayer().getLocation()).inSight();
                    Util.setVisibility(inSight && !showBypassPlayers.contains(e.getPlayer()), p2, e.getPlayer(), plugin);
                    Util.setVisibility(inSight && !showBypassPlayers.contains(p2), e.getPlayer(), p2, plugin);
                });
        }

        if(hunters.contains(e.getPlayer()) ? hunterReleased : movable) return;
        //HACK: WorldInstanceのnullチェックこれでええんか...？
        if(worldInstance == null) return;
        if(worldInstance.world == null) return;
        if(!e.getFrom().getWorld().equals(worldInstance.world)) return;
        e.setTo(
            new Location(
                e.getTo().getWorld(),
                e.getFrom().getX(),
                e.getFrom().getY(),
                e.getFrom().getZ(),
                e.getTo().getYaw(),
                e.getTo().getPitch()
            )
        );
    }

    void jail(Player runner, Player hunter) {
        //ゲームが始まっていなければ何もしない
        if(!inGame) return;
        //逃走者じゃなかったり、すでに牢屋に入っている場合は何もしない
        if(!this.runners.contains(runner) || this.jailed.contains(runner)) return;
        this.jailed.add(runner);
        runner.getInventory().clear();
        Location jail =
            map.locations.jailClosest
            .add(new Vec3D(map.locations.jailFarthest.x, map.locations.jailClosest.y, map.locations.jailFarthest.z))
            .scalarScale(0.5)
            .withWorld(worldInstance.world);
        hunter.playSound(hunter.getLocation(), Sound.ITEM_TRIDENT_THUNDER, Integer.MAX_VALUE, 1.0f);
        runner.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0 , false, false, false));
        runner.teleport(jail);
        runner.playSound(runner.getLocation(), Sound.ITEM_TRIDENT_THUNDER, 1.0f, 1.0f);
        plugin.getServer().getScheduler().runTaskLater(plugin, () ->
            runner.sendTitle(Util.getColoredString("ハンターに捕まってしまった", ChatColor.RED), "牢屋に転送されます...", 7, 25, 7)
        , 5L);

        List<Player> notifier = this.match.participants.stream()
            .filter(v -> this.runners.contains(v))
            .filter(v -> !v.equals(runner))
            .collect(Collectors.toList());

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> notifier.forEach(p -> p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.0f)), 15);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> notifier.forEach(p -> p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.0f)), 17);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> notifier.forEach(p -> p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.0f)), 19);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> notifier.stream()
            .peek(p -> p.sendMessage(""))
            .peek(p -> p.sendMessage("==== MAIL ===="))
            .peek(p -> p.sendMessage("確保情報: " + runner.getName() + "が確保された"))
            .forEach(p -> p.sendMessage(""))
        , 22);

        // HACK: そのまま containsAllするとパフォーマンスが低下するらしい？(ソース：IntelliJIDEA君)
        if (!new HashSet<>(jailed).containsAll(runners)) {
            TextComponent msg = new TextComponent(Util.getColoredString("[観戦モードにする]", ChatColor.GREEN, ChatColor.BOLD));
            msg.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/runmc-wanna-switch-spectate"));

            TextComponent msgBefore = new TextComponent("\n捕まってしまいました...\n");
            TextComponent msgAfter = new TextComponent("\n");
            runner.sendMessage(msgBefore, msg, msgAfter);
        }



        checkGameEndCondition();
        //FIXME: JAILから出れないようにする処理が必要
    }

    @EventHandler
    public void onInteractArmorStand(PlayerArmorStandManipulateEvent e) {
        if (e.getSlot() != EquipmentSlot.HEAD) return;
        // TODO: ArmorStandItem()とPlayerItem()は状態が変更される前を指すのか、変化した後を指すのかが不明なので判明した後修正する
        if (e.getArmorStandItem().getItemMeta() instanceof SkullMeta) return;
        SkullMeta meta = (SkullMeta) e.getArmorStandItem().getItemMeta();
        if (spectators.containsKey(Objects.requireNonNull(meta.getOwningPlayer()).getPlayer()))
            e.setCancelled(true);
    }

    @EventHandler
    public void onEntityDamageByBlock(EntityDamageByBlockEvent e) {
        if(!(e.getEntity() instanceof Player && this.match.participants.contains((Player) e.getEntity()) && e.getEntity().getLocation().getWorld().equals(worldInstance.world))) return;
        e.setCancelled(true);
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent e) {
        if(!(e.getEntity() instanceof Player && this.match.participants.contains((Player) e.getEntity()) && e.getEntity().getLocation().getWorld().equals(worldInstance.world))) return;
        e.setCancelled(true);
        if(e.getDamager() instanceof Player && e.getEntity() instanceof Player) {
            Player damager = (Player) e.getDamager();
            Player damaged = (Player) e.getEntity();

            //ダメージを与えた人がハンター かつ ダメージを受けた人が逃走者 かつ ダメージを受けた人は牢屋にまだ入っていない
            if (this.hunters.contains(damager) && this.runners.contains(damaged) && !this.jailed.contains(damaged)) {
                jail(damaged, damager);
            }
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if(e.getInventory().getHolder() instanceof Player) {
            //ハンターの頭を外せないようにする
            if(e.getCurrentItem() != null) {
                if (e.getCurrentItem().getType() == Material.PLAYER_HEAD || e.getCurrentItem().getType() == Material.CHAINMAIL_CHESTPLATE)
                    e.setCancelled(true);
            }
        }
    }

    public void wannaBeSpectate(Player p) {
        if(!jailed.contains(p)) return;
        ArmorStand armorStand = worldInstance.world.spawn(p.getLocation(), ArmorStand.class, v -> {
            v.setHelmet(Util.getPlayerHead(p));
            v.setInvulnerable(true);
            v.setBasePlate(false);
            v.setGravity(false);
            v.addScoreboardTag(p.getName());
        });
        spectators.put(p, armorStand);
        worldInstance.world.getPlayers().stream()
            .peek(v -> {
                if(v.isFlying()) {
                    p.hidePlayer(plugin, v);
                } else {
                    p.showPlayer(plugin, v);
                }
            })
            .forEach(v -> v.hidePlayer(plugin, p));

        p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 18000, 1, false, false));
        p.setAllowFlight(true); // 念のため
        p.setFlying(true);
        TextComponent msg = new TextComponent(Util.getColoredString("[牢屋に戻る]", ChatColor.GREEN, ChatColor.BOLD));
        TextComponent returnMsg = new TextComponent("\n");
        msg.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/runmc-wanna-switch-spectate"));
        p.sendMessage(returnMsg, msg, returnMsg);
    }

    public void returnToJail(Player p) {
        if (!jailed.contains(p)) return;
        worldInstance.world.getPlayers().forEach(v -> v.showPlayer(plugin, p));
        spectators.entrySet().stream()
            .filter(v -> v.getValue().getScoreboardTags().contains(p.getName()) && v.getKey().equals(p))
            .findFirst()
            .ifPresent(v -> {
                p.setFlying(false);
                p.setAllowFlight(false);
                p.teleport(v.getValue().getLocation());
                v.getValue().remove();
                spectators.remove(p);
            });
    }

    public void release() {
        worldInstance.dispose(plugin.specialLocation.lobbySpawn);
    }

    public enum GameEndReason {
        TIMEOUT,
        NO_AVAILABLE_HUNTER,
        NO_AVAILABLE_RUNNER,
        SERVER_RELOAD,
    }
}

