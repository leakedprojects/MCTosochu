package dev.mctosochu.main.tosochumain.match;

import dev.mctosochu.main.tosochumain.TosochuMain;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.ArrayList;
import java.util.Optional;

// プレイヤーをどのマッチに打ち込むかを選択します。
public class SelectMatchStrategy implements Listener {

    TosochuMain plugin;

    public ArrayList<Match> matches = new ArrayList<>();

    //マッチメイキング中
    ArrayList<Player> matchMakeWaiting = new ArrayList<>();

    public SelectMatchStrategy(TosochuMain plugin) {
        this.plugin = plugin;
        this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
    }

    @EventHandler
    public void quit(PlayerQuitEvent e) {
        this.matchMakeWaiting.remove(e.getPlayer());
    }


    public void newComer(Player p) {
        if(matchMakeWaiting.contains(p)) {
            //もう既にマッチメイキング中
            p.sendMessage("既にマッチメイキング中です...");
            return;
        }


        p.sendMessage("マッチメイキング...");
        matchMakeWaiting.add(p);

        Optional<Match> smallest = this.matches.stream()
            //試合が開始していないもの（参加可能なマッチ）に絞る
            .filter(match -> match.joinable)
            //1ゲームが10人を超えないようにする
            .filter(match -> match.participants.size() < 10)
            //最も参加人数が多いものを取り出す
            .reduce((base, value) -> base.participants.size() < value.participants.size() ? value : base);

        smallest
            //条件を満たすマッチがなかった場合、新しくマッチを作る。
            .orElseGet(() -> {
                Match newMatch = new Match(plugin);
                matches.add(newMatch);
                return newMatch;
            })
            //プレイヤーを参加させる。
            .join(p);
    }

    public void teleported(Player p) {
        this.matchMakeWaiting.remove(p);
    }

    public void matchRelease(Match match) {
        this.matches.remove(match);
    }

    public Optional<Match> getMatchByPlayer(Player p) {
        return matches.stream().filter(m -> m.participants.contains(p)).findFirst();
    }

    public Optional<Game> getGameByPlayer(Player p) {
        Optional<Match> m = getMatchByPlayer(p);
        return m.isEmpty() ? Optional.empty() : Optional.ofNullable(m.get().game);

    }
}
