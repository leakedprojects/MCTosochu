package dev.mctosochu.main.tosochumain.mission;

import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.match.Game;
import dev.mctosochu.main.tosochumain.util.DispatchableTimer;
import dev.mctosochu.main.tosochumain.util.Util;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.Nullable;

public class PreventSpeedupHunterMission extends Mission {
    public final Location leverLoc;

    private DispatchableTimer timer;

    public PreventSpeedupHunterMission(TosochuMain plugin, Game game) {
        super(plugin, game, "station", 2);
        this.leverLoc = new Location(this.game.worldInstance.world, 129, 77, -129);
    }

    @Override
    public void trigger() {
        this.game.missionManager.isMissionRunning = true;

        this.game.runners.forEach(p -> {
            p.sendMessage("\n--------------- MISSION\n" +
                              "残り時間６分になるとハンターの速度が上昇する\n" +
                              "阻止するには時間内に地上ホームにあるレバーを\n" +
                              "下ろさなければならない\n"
            );
        });

        this.timer = new DispatchableTimer(this.plugin, 180);
        timer.schedule(180, () -> {
            this.game.runners.forEach(p -> {
                p.sendMessage("\n--------------- MAIL\n" +
                                  "ミッション失敗\n" +
                                  "ハンターの速度が上昇した\n"
                );
            });
            this.game.hunters.forEach(p -> {
                p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, false, false, true));
            });
            this.end(null, false);
        });
    }

    @EventHandler
    public void onLeverPowered(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getClickedBlock() == null || !e.getClickedBlock().getLocation().equals(this.leverLoc)) return;
        if (e.getClickedBlock().isBlockPowered())
            this.end(e.getPlayer(), true);
    }

    @Override
    protected void end(@Nullable Player player, boolean isSucceed) {
        if (isSucceed && player != null) {
            player.sendMessage(Util.getColoredString("レバーを下しました", ChatColor.GREEN));
            this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
                this.game.runners.forEach(p -> {
                    p.sendMessage("\n--------------- MAIL\n" +
                                      player + " さんの活躍により\nハンターの速度上昇は阻止された\n"
                    );
                });
            }, 100L);
        }
        this.game.worldInstance.world.getBlockAt(129, 77, -129).setType(Material.AIR);
        this.game.worldInstance.world.getBlockAt(130, 77, -129).setType(Material.AIR);
        this.game.worldInstance.world.getBlockAt(130, 76, -129).setType(Material.AIR);
        this.timer.cancel();
    }
}
