package dev.mctosochu.main.tosochumain.command.manager;

import dev.mctosochu.main.tosochumain.TosochuMain;
import org.bukkit.command.CommandSender;

public class CommandExecutedInfo {
    public CommandSender sender;
    public String[] args;
    public CommandExecutedInfo(CommandSender sender, String[] args) {
        this.sender = sender; this.args = args;
    }
    public void sendMessage(String text) {
        this.sender.sendMessage(TosochuMain.messagePrefix + text);
    }
}
