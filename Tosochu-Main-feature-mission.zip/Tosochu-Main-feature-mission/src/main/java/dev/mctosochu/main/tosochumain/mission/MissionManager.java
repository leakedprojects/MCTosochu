package dev.mctosochu.main.tosochumain.mission;

import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.match.Game;
import dev.mctosochu.main.tosochumain.util.DispatchableTimer;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MissionManager {
    Map<Integer, List<Mission>> missions;
    final TosochuMain plugin;
    final Game game;
    final DispatchableTimer timer;

    public boolean isMissionRunning = false;

    public MissionManager(TosochuMain plugin, Game game, DispatchableTimer timer) {
        this.plugin = plugin;
        this.game = game;
        this.timer = timer;

        missions = new HashMap<>() {{
            put(360, List.of(new PreventSpeedupHunterMission(plugin, game)));
            put(180, List.of(new ItemChallengeMission(plugin, game)));
        }};
    }

    public void startMissions() {
        missions.forEach((key, value) -> timer.schedule(key, () -> {
            value.stream()
                .filter(this::isMissionAvailable)
                .findAny()
                .ifPresent(Mission::trigger);
        }));
    }

    private boolean isMissionAvailable(Mission mission) {
        List<Player> availableRunners = this.game.match.participants.stream()
            .filter(p -> !this.game.hunters.contains(p))
            .filter(p -> !this.game.jailed.contains(p))
            .collect(Collectors.toList());
        if (!this.game.map.id.equals(mission.worldName)) return false;
        if (availableRunners.size() < mission.minimumRequirePlayers) return false;
        if (this.isMissionRunning) return false;
        return true;
    }
}
