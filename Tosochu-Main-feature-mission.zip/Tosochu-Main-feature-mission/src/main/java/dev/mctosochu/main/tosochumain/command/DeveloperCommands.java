package dev.mctosochu.main.tosochumain.command;

import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.command.manager.CommandManager;
import dev.mctosochu.main.tosochumain.util.PlayerInsight;
import org.bukkit.entity.Player;

public class DeveloperCommands {
    public DeveloperCommands(TosochuMain plugin, CommandManager cm) {
        cm.addSubCommand(new String[]{ "dev", "normalize" }, info -> {
            if (!(info.sender instanceof Player)) return false;
            plugin.lobbyWorldNormalizer.normalize((Player) info.sender);
            return true;
        });

        cm.addSubCommand(new String[]{ "dev", "reachable" }, info -> {
            if (!(info.sender instanceof Player)) return false;
            Player p = (Player) info.sender;
            long startTime = System.currentTimeMillis();

            plugin.getServer().getOnlinePlayers().stream().filter(p2 -> !p2.equals(p))
                .forEach(p2 -> {
                    if(new PlayerInsight(p2.getLocation(), p.getLocation()).inSight()) {
                        p.sendMessage(p2.getName() + ": In Sight!");
                    } else {
                        p.sendMessage(p2.getName() + ": NOT In Sight!");
                    }
                });
            long endTime = System.currentTimeMillis();
            p.sendMessage((endTime - startTime) + "ms");
            return true;
        });
    }
}
