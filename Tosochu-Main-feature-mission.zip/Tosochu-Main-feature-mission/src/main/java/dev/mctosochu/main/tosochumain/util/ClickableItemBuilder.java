package dev.mctosochu.main.tosochumain.util;

import dev.mctosochu.main.tosochumain.TosochuMain;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;

public class ClickableItemBuilder {
    private Material material;
    private String name;

    @Nullable
    ItemStack stack = null;

    TosochuMain plugin;

    public ClickableItemBuilder(TosochuMain plugin) {
        this.plugin = plugin;
    }

    public ClickableItemBuilder setMaterial(Material material) {
        this.material = material;
        return this;
    }

    // 色付きの名前にしたいときはここで Util#getColoredString を使う
    public ClickableItemBuilder setName(String name) {
        this.name = name;
        return this;
    }


    ItemStack getItemStack() {
        return Util.getNamedItemStack(this.material, this.name);
    }

    public ClickableItem build() {
        return new ClickableItem(plugin, getItemStack());
    }

}
