package dev.mctosochu.main.tosochumain.command;

import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.command.manager.CommandManager;
import dev.mctosochu.main.tosochumain.match.Game;
import dev.mctosochu.main.tosochumain.match.Match;
import org.bukkit.permissions.ServerOperator;

public class ReloadCommand {
    public ReloadCommand(TosochuMain plugin, CommandManager cm) {
        cm.addSubCommand(new String[]{ "safeReload" }, info -> {

            //実行中のゲームをすべて終了
            plugin.selectMatchStrategy.matches
                .stream()
                .filter(v -> v.game != null)
                .filter(v -> v.game.inGame)
                .forEach(v -> v.game.end(Game.GameEndReason.SERVER_RELOAD));

            plugin.getServer().getScheduler().runTaskLater(plugin, () ->
                    plugin.selectMatchStrategy.matches.forEach(Match::matchRelease)
            , 20L);

            plugin.getServer().getScheduler().runTaskLater(plugin, () ->
                plugin.getServer().getOnlinePlayers().stream().filter(ServerOperator::isOp)
                    .forEach(p -> p.sendMessage("Reloading..."))
            , 85L);

            plugin.getServer().getScheduler().runTaskLater(plugin, () ->
                plugin.getServer().dispatchCommand(
                    plugin.getServer().getConsoleSender(), "plugman reload Tosochu-Main"
                )
            , 90L);

            return true;
        });
    }
}
