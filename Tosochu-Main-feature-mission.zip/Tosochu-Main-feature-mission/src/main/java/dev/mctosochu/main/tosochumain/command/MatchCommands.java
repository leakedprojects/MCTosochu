package dev.mctosochu.main.tosochumain.command;

import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.command.manager.CommandManager;
import dev.mctosochu.main.tosochumain.match.SelectMatchStrategy;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.concurrent.atomic.AtomicInteger;

public class MatchCommands {

    public MatchCommands(TosochuMain plugin, CommandManager cm, SelectMatchStrategy sms) {
        cm.addSubCommand(new String[]{ "match", "forcestart" }, info -> {
            if (!(info.sender instanceof Player)) return false;
            sms.matches.stream()
                .filter(match -> match.participants.contains(info.sender))
                .findFirst()
                .ifPresentOrElse(m -> {
                    info.sendMessage("Force starting...");
                    m.forceStart();
                }, () -> info.sendMessage("Run it with you in the match!"));
            return true;
        });
        cm.addSubCommand(new String[]{ "match", "voteskip" }, info -> {
            if (!(info.sender instanceof Player)) return false;
            sms.matches.stream()
                .filter(match -> match.participants.contains(info.sender))
                .findFirst()
                .ifPresentOrElse(m -> {
                    info.sendMessage("Skip to 5 seconds...");
                    m.voteSkip();
                }, () -> info.sendMessage("Run it with you in the match!"));
            return true;
        });
        cm.addSubCommand(new String[]{ "match", "wherewho" }, info -> {
            info.sendMessage("");
            info.sender.sendMessage("=== Matches and participating Players === \n");
            sms.matches.forEach(match -> {
                info.sender.sendMessage(ChatColor.AQUA + "Match id:" + match.uniqueId + " " + (match.joinable ? "*joinable" : ""));
                info.sender.sendMessage(ChatColor.WHITE + "- Players(" + match.participants.size() + ")");
                AtomicInteger i = new AtomicInteger(1);
                match.participants
                    .forEach(player -> {
                        if (i.get() == 11) {
                            info.sender.sendMessage(ChatColor.GRAY+ ".  (...other " + (match.participants.size() - 10) + " players)");
                        }
                        if (i.getAndIncrement() < 11){
                            info.sender.sendMessage(ChatColor.GRAY+ ".  - " + player.getName());
                        }
                    });
                info.sender.sendMessage();
            });
            info.sender.sendMessage(ChatColor.AQUA + "Lobby ");
            info.sender.sendMessage(ChatColor.WHITE + "- Players(" + plugin.specialLocation.lobbyWorld.getPlayers().size() + ")");

            AtomicInteger i = new AtomicInteger(1);
            plugin.specialLocation.lobbyWorld.getPlayers().forEach(player -> {
                if (i.get() == 11) {
                    info.sender.sendMessage(ChatColor.GRAY+ ".  (...other " + (plugin.specialLocation.lobbyWorld.getPlayers().size() - 10) + " players)");
                }
                if (i.getAndIncrement() < 11){
                    info.sender.sendMessage(ChatColor.GRAY+ ".  - " + player.getName());
                }
            });

            info.sender.sendMessage();
            info.sender.sendMessage("=== Matches and participating Players === ");
            return true;
        });
    }
}
