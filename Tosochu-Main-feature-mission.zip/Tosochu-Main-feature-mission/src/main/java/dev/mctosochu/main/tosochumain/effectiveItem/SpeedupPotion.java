package dev.mctosochu.main.tosochumain.effectiveItem;

import dev.mctosochu.main.tosochumain.TosochuMain;
import dev.mctosochu.main.tosochumain.util.ClickableItem;
import dev.mctosochu.main.tosochumain.util.Util;
import org.bukkit.Color;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SpeedupPotion extends EffectiveItem {
    ItemStack item;

    public SpeedupPotion(TosochuMain plugin) {
        super(plugin);

        item = Util.getColoredPotion("速度上昇ポーション", Util.PotionType.SPLASH, Color.AQUA);
        item.setAmount(1);
        item.setLore(Arrays.asList(
            "30秒間、使用者とその付近にいる",
            "ハンターを除くプレイヤーの足が速くなる。",
            "（右クリックで使用）"
        ));

        new ClickableItem(plugin, item)
            .setRequireOp(false)
            .addAction(this::use);
    }

    private void use(Player p) {
        plugin.selectMatchStrategy.getGameByPlayer(p).ifPresent(g -> {
            if (!g.runners.contains(p)) return;
            EffectiveItemManager.discountAmount(p, item);
            p.sendMessage(
                "-----\n" +
                "*あなたは速度上昇ポーションを使用した\n" +
                " (速度上昇: 30秒間)\n" +
                "-----"
            );
            List<Player> players = p.getNearbyEntities(3.0, 0.5, 3.0).stream()
                .filter(v -> v.getType() == EntityType.PLAYER)
                .map(v -> (Player) v)
                .filter(v -> g.runners.contains(v))
                .collect(Collectors.toList());
            players.add(p);
            players.stream()
                .peek(v -> v.playSound(v.getLocation(), Sound.ENTITY_SPLASH_POTION_BREAK, 1.0f, 1.0f))
                .peek(v -> v.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 600, 0, false, false, true)))
                .forEach(v -> plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                    v.sendMessage("*速度上昇の効果が切れました");
                    v.playSound(v.getLocation(), Sound.BLOCK_CONDUIT_DEACTIVATE, 1.0f, 1.0f);
                    v.removePotionEffect(PotionEffectType.SPEED);
                }, 600L));
        });
    }

    @Override
    public ItemStack given() {
        return item;
    }
}
