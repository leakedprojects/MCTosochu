## Commands

<br>

### /runmc safeReload

すべてのマッチを終了させてから、安全にリロードします。

<br>

### /runmc match wherewho
![image](https://user-images.githubusercontent.com/84216737/180643446-9330f248-2d53-493b-86c9-2445e1aa7e64.png)

各マッチに誰がいるのかを表示します。また、参加可能(試合が始まっていない)マッチには `*joinable` と表示されます。

上の画像では、試合が始まっていないマッチにAsPulseさんが一人、ロビーには誰も居ないことを示しています。

<br>

### /runmc match forcestart

マッチに4人集まっていなくても、ゲーム開始のカウントダウンを始めます。

<br>

### /runmc match voteskip

マップ投票のタイマーを残り5秒までスキップします。

<br>
