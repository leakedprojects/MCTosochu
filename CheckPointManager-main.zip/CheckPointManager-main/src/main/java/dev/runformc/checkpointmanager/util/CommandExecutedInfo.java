// 昔自分がつくったやつで、便利なので私 (AsPulse) は普段コピペで使いまわしてます

package dev.runformc.checkpointmanager.util;

import dev.runformc.checkpointmanager.Checkpointmanager;
import org.bukkit.command.CommandSender;

public class CommandExecutedInfo {
    public CommandSender sender;
    public String[] args;
    public CommandExecutedInfo(CommandSender sender, String[] args) {
        this.sender = sender; this.args = args;
    }
    public void say(String content) {
        sender.sendMessage(Checkpointmanager.messagePrefix + content);
    }
}