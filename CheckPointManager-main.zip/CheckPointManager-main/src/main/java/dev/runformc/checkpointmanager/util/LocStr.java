package dev.runformc.checkpointmanager.util;

import org.bukkit.Location;

public class LocStr {
    //Locationを、見やすい文字列に変換します。
    public static String fromLocation(Location l) {
        return "[" + l.getWorld().getName() + "](" + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ() + ")";
    }
}
