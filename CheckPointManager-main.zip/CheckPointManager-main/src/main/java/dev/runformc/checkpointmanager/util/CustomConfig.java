package dev.runformc.checkpointmanager.util;

import dev.runformc.checkpointmanager.Checkpointmanager;
import dev.runformc.checkpointmanager.checkpoint.CheckPoint;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

//Configを便利に扱うためのクラスです
public class CustomConfig {
    private final Checkpointmanager main;
    private FileConfiguration config = null;

    public HashMap<String, CheckPoint> checkpoints = new HashMap<>();

    public CustomConfig(Checkpointmanager plugin) {
        main = plugin;
        reload();
    }

    public void reload() {
        //config.ymlが存在しない場合は生成します。
        main.saveDefaultConfig();

        //configがすでに存在している場合はリロードを行います。
        if ( config != null ) {
            main.reloadConfig();
        }

        //現在のconfig.ymlをロードします。
        config = main.getConfig();

        serialize();
    }

    //configファイルのデータ(FileConfiguration) を、変数に格納します。
    public void serialize() {
        serializeCheckpoints();
    }

    //チェックポイントの名前の一覧を取得
    public Set<String> listCheckPoint() {
        ConfigurationSection section = config.getConfigurationSection("checkpoints");
        if (section == null) {
            //config.ymlに存在しない場合
            return new HashSet<>();
        } else {
            return section.getKeys(false);
        }
    }
    // 例外ポイントのリスト取得
    private Set<String> listIgnorePoint(String chkpointName) {
        ConfigurationSection section = config.getConfigurationSection("checkpoints." + chkpointName + ".ignore");
        if (section == null)
            return new HashSet<>();
        else
            return section.getKeys(false);
    }
    //config.ymlのチェックポイントリストから、
    public void serializeCheckpoints() {

        //チェックポイントの名前の一覧です。
        Set<String> pointNames = listCheckPoint();

        checkpoints = pointNames.stream().map(v -> {
            String pathPrefix = "checkpoints." + v + ".";
            String ignorePrefix = pathPrefix + "ignore.";
            List<Location> ignores = listIgnorePoint(v).stream().map(p -> new Location(main.getServer().getWorld(UUID.fromString(config.getString(pathPrefix + ".world.range"))),
                                                                      config.getDouble(ignorePrefix + p + "X"),
                                                                      config.getDouble(ignorePrefix + p + "Y"),
                                                                      config.getDouble(ignorePrefix + p + "Z"))
                        ).collect(Collectors.toList());
            return new CheckPoint(
                v,
                main.getServer().getWorld(UUID.fromString(config.getString(pathPrefix + ".world.range"))),
                config.getDouble(pathPrefix + ".start.X"),config.getDouble(pathPrefix + ".start.Y"),config.getDouble(pathPrefix + ".start.Z"),
                config.getDouble(pathPrefix + ".end.X"),config.getDouble(pathPrefix + ".end.Y"),config.getDouble(pathPrefix + ".end.Z"),
                new Location(
                    main.getServer().getWorld(UUID.fromString(config.getString(pathPrefix + ".world.spawn"))),
                    config.getDouble(pathPrefix + ".spawn.X"),config.getDouble(pathPrefix + ".spawn.Y"),config.getDouble(pathPrefix + ".spawn.Z")
                ),
                ignores
            );
        }).collect(Collectors.toMap(
            v -> v.pointName, //Mapのキーを渡すlambda
            v -> v, //Mapの値を渡すlambda
            (v1, v2) -> v1, // 重複した際にどちらを採用するか（先勝ち）,
            HashMap::new
        ));

        main.getLogger().info("Loaded " + checkpoints.size() + " checkpoint(s)");
    }

    public void deserializeCheckpoints() {

        Set<String> pointNames = listCheckPoint();

        //config.yml上の現存するチェックポイントを全て削除します
        //nullを代入することで削除できます
        pointNames.forEach(v -> config.set("checkpoints." + v, null));

        checkpoints.values().stream().map(p -> {
            HashMap<String, Object> map = new HashMap<>();
            map.put("name", p.pointName);
            map.put("world.range", p.rangeWorld.getUID().toString());
            map.put("world.spawn", p.spawnPoint.getWorld().getUID().toString());
            map.put("start.X", p.startPoint.getX());
            map.put("start.Y", p.startPoint.getY());
            map.put("start.Z", p.startPoint.getZ());
            map.put("end.X", p.endPoint.getX());
            map.put("end.Y", p.endPoint.getY());
            map.put("end.Z", p.endPoint.getZ());
            map.put("spawn.X", p.spawnPoint.getX());
            map.put("spawn.Y", p.spawnPoint.getY());
            map.put("spawn.Z", p.spawnPoint.getZ());
            IntStream.range(0, p.ignorePoint.size()).forEach(v -> {
                map.put("ignore." + v + ".X", p.ignorePoint.get(v).getX());
                map.put("ignore." + v + ".Y", p.ignorePoint.get(v).getY());
                map.put("ignore." + v + ".Z", p.ignorePoint.get(v).getZ());
            });
            return map;
        }).forEach(v -> {
            String pathPrefix = "checkpoints." + v.get("name") + ".";
            v.forEach((key, value) -> config.set(pathPrefix + key, value));
        });
        main.getLogger().info("Saved " + checkpoints.size() + " checkpoint(s)");
        save();
    }

    //次のチェックポイント名を生成
    public String provideNextCheckpointName() throws Exception {
        //CheckPoint1 → CheckPoint2 → CheckPoint3... のように走査し、使われていないものが見つかれば返します。
        //Checkpointの最大数は4096個です。
        for(int i = 1; i <= 4096; i++) {
            String nextName = "CheckPoint" + i;
            if (checkpoints.containsKey(nextName)) continue;
            return nextName;
        }
        throw new Exception("Checkpointの最大数は4096個です。");
    }

    //config.ymlに書き込みます。
    public void save() {
        main.saveConfig();
    }

}
