package dev.runformc.checkpointmanager.checkpoint;

public enum CheckPointCreationStatus {
    NoCheckPoint, //何も作成中のチェックポイントが無い
    SetStartPoint, //始点のみ設定済み
    SetEndPoint, //終点のみ設定済み
}
