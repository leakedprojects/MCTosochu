// 昔自分がつくったやつで、便利なので私 (AsPulse) は普段コピペで使いまわしてます

package dev.runformc.checkpointmanager.util;

import dev.runformc.checkpointmanager.Checkpointmanager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class CommandManager implements CommandExecutor, TabCompleter {
    Checkpointmanager main;
    public CommandManager (Checkpointmanager plugin) {
        main = plugin;
        Objects.requireNonNull(main.getCommand("chkpoint")).setExecutor(this);
    }
    public HashMap<String[], Predicate<CommandExecutedInfo>> Commands = new HashMap<>();
    public HashMap<String[], Predicate<CommandExecutedInfo>> Interacts = new HashMap<>();

    public void addSubCommand(String[] args, Predicate<CommandExecutedInfo> lambda) {
        Commands.put(args, lambda);
    }
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        return Commands.entrySet().stream()
                .filter(v -> {
                    for (int i = 0; i < v.getKey().length; i++) {
                        if ( !v.getKey()[i].equals(args[i]) ) return false;
                    }
                    return true;
                }).findFirst()
                .map(v -> {
                    if (v.getValue() == null) {
                        sender.sendMessage(Checkpointmanager.messagePrefix + ChatColor.RED + "This command not implemented."); return false;
                    } else {
                        return v.getValue().test(new CommandExecutedInfo(sender, args));
                    }
                })
                .orElseGet(() -> {
                    sender.sendMessage(Checkpointmanager.messagePrefix + ChatColor.RED + "Subcommand not found."); return false;
                });
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completes = Commands.keySet().stream()
                .filter(v -> v.length >= args.length)
                .filter(v ->
                        Arrays.stream(v).limit(args.length - 1).collect(Collectors.toList()).equals(
                                Arrays.stream(args).limit(args.length - 1).collect(Collectors.toList())
                        )
                )
                .map(v -> v[args.length - 1])
                .collect(Collectors.toList());
        return completes.isEmpty() ? main.onTabComplete(sender, command, alias, args) : completes;
    }
}
