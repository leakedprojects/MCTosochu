package dev.runformc.checkpointmanager.checkpoint;

import org.bukkit.Location;
import org.bukkit.World;
import java.util.ArrayList;
import java.util.List;

//チェックポイントを表すクラスです。
public class CheckPoint {
    public String pointName;
    public Location startPoint;
    public Location endPoint;
    public Location spawnPoint;
    public List<Location> ignorePoint;
    public World rangeWorld;
    public boolean isReady = false;

    public CheckPoint(String name, World range, double startX, double startY, double startZ, double endX, double endY, double endZ, Location spawn, List<Location> ignore) {
        pointName = name;
        rangeWorld = range;
        startPoint = new Location(rangeWorld, startX, startY, startZ);
        endPoint = new Location(rangeWorld, endX, endY, endZ);
        spawnPoint = spawn;
        this.ignorePoint = ignore;
        isReady = true;
    }

    public CheckPoint(String name) {
        pointName = name;
        rangeWorld = null;
        startPoint = null;
        endPoint = null;
        spawnPoint = null;
        ignorePoint = new ArrayList<>();
        isReady = false;
    }
    //ある場所が、startPoint-endPointの中に入ってるか判断します。
    public boolean isInRange(Location l) {
        //もし違うワールドにいたら「入っていない」という結論を返します（アーリーリターン）
        if (!startPoint.getWorld().getUID().equals(l.getWorld().getUID())) return false;

        //X, Y, Z それぞれの座標で最小座標より小さいものがあれば「入っていない」という結論を返します。
        if(Math.min(startPoint.getBlockX(), endPoint.getBlockX()) > l.getBlockX()) return false;
        if(Math.min(startPoint.getBlockY(), endPoint.getBlockY()) > l.getBlockY()) return false;
        if(Math.min(startPoint.getBlockZ(), endPoint.getBlockZ()) > l.getBlockZ()) return false;

        //X, Y, Z それぞれの座標で最大座標より大きいものがあれば「入っていない」という結論を返します。
        if(Math.max(startPoint.getBlockX(), endPoint.getBlockX()) < l.getBlockX()) return false;
        if(Math.max(startPoint.getBlockY(), endPoint.getBlockY()) < l.getBlockY()) return false;
        if(Math.max(startPoint.getBlockZ(), endPoint.getBlockZ()) < l.getBlockZ()) return false;

        //ここまでのチェックを通過すれば、「入っている」という結論を返します。
        return true;
    }
}
