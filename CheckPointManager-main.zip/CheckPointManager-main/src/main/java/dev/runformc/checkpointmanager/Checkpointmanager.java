package dev.runformc.checkpointmanager;

import dev.runformc.checkpointmanager.checkpoint.CheckPoint;
import dev.runformc.checkpointmanager.checkpoint.CheckPointCreationStatus;
import dev.runformc.checkpointmanager.util.CommandExecutedInfo;
import dev.runformc.checkpointmanager.util.CommandManager;
import dev.runformc.checkpointmanager.util.CustomConfig;
import dev.runformc.checkpointmanager.util.LocStr;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Optional;

public final class Checkpointmanager extends JavaPlugin implements Listener {

    // コマンド実行結果の先頭につけるやつを定義
    final static public String messagePrefix =
            ChatColor.GRAY + "[" + ChatColor.AQUA + "CheckPointManager" + ChatColor.GRAY + "]" + ChatColor.RESET + " ";


    CustomConfig config;
    CommandManager cm;

    //最初作成中のチェックポイントはない
    CheckPointCreationStatus cpcs = CheckPointCreationStatus.NoCheckPoint;
    CheckPoint creatingCheckPoint = null;

    private void rejectCommandWithWrongStatus(CommandExecutedInfo v) {
        v.say("このコマンドは、");
        v.say("/chkpoint start, /chkpoint end, /chkpoint ignore, /chkpoint spawnの順で使用します。");
        if (cpcs != CheckPointCreationStatus.NoCheckPoint) {
            v.say("もし現在制作中のチェックポイントをキャンセルする場合、");
            v.say("/chkpoint cancel を 使用してください。");
        }
    }

    private Player getPlayer(CommandExecutedInfo v) {
        //コマンドをつかった人がプレイヤーでなければ
        if(!(v.sender instanceof Player)) {
            v.say("このコマンドはプレイヤーが使用しなければなりません。");
            return null;
        }
        return (Player) v.sender;
    }

    @Override
    public void onEnable() {
        // Plugin startup logic
        config = new CustomConfig(this);
        cm = new CommandManager(this);
        getServer().getPluginManager().registerEvents(this, this);

        //./chkpoint startコマンド
        cm.addSubCommand(new String[]{"start"}, v -> {
            v.sender.sendMessage("");
            //現在生成中のチェックポイントは無いことを確認
            if (cpcs != CheckPointCreationStatus.NoCheckPoint) {
               rejectCommandWithWrongStatus(v);
               return true;
            }
            Player p = getPlayer(v);
            if (p == null) return true;

            try {
                creatingCheckPoint = new CheckPoint(config.provideNextCheckpointName());
                creatingCheckPoint.rangeWorld = p.getWorld();
                creatingCheckPoint.startPoint = p.getLocation().getBlock().getLocation().clone();
                v.say("始点を設定しました: " + LocStr.fromLocation(creatingCheckPoint.startPoint));
                v.say("/chkpoint end で終点を設定します...");
                cpcs = CheckPointCreationStatus.SetStartPoint;
            } catch (Exception e) {
                v.say("Checkpointの最大数は4096個です");
                e.printStackTrace();
            }
            return true;
        });

        //./chkpoint endコマンド
        cm.addSubCommand(new String[]{"end"}, v -> {
            v.sender.sendMessage("");
            //現在始点が設定されたことを確認
            if (cpcs != CheckPointCreationStatus.SetStartPoint) {
                rejectCommandWithWrongStatus(v);
            }
            Player p = getPlayer(v);
            if (p == null) return true;
            creatingCheckPoint.endPoint = p.getLocation().getBlock().getLocation().clone();
            v.say("範囲を設定しました: ");
            v.say(LocStr.fromLocation(creatingCheckPoint.startPoint) + " ..→.. " + LocStr.fromLocation(creatingCheckPoint.endPoint));
            v.say("/chkpoint spawn でスポーン地点を設定します...");
            v.say("/chkpoint ignore で例外地点を設定できます...");
            cpcs = CheckPointCreationStatus.SetEndPoint;
            return true;
        });

        //./chkpoint spawnコマンド
        cm.addSubCommand(new String[]{"spawn"}, v -> {
            v.sender.sendMessage("");
            //現在終点が設定されたことを確認
            if (cpcs != CheckPointCreationStatus.SetEndPoint) {
                rejectCommandWithWrongStatus(v);
                return true;
            }
            Player p = getPlayer(v);
            if (p == null) return true;
            creatingCheckPoint.spawnPoint = p.getLocation().getBlock().getLocation().clone();
            v.say("チェックポイント:  " + creatingCheckPoint.pointName + " を作成しました。");
            //チェックポイントをconfigに追加
            creatingCheckPoint.isReady = true;
            config.checkpoints.put(creatingCheckPoint.pointName, creatingCheckPoint);
            config.deserializeCheckpoints();

            cpcs = CheckPointCreationStatus.NoCheckPoint;
            creatingCheckPoint = null;
            config.deserializeCheckpoints();
            return true;
        });

        //./chkpoint cancelコマンド
        cm.addSubCommand(new String[]{"cancel"}, v -> {
            cpcs = CheckPointCreationStatus.NoCheckPoint;
            creatingCheckPoint = null;
            v.sender.sendMessage("");
            v.say("キャンセルしました。");
            return true;
        });

        // ./chkpoint listコマンド
        cm.addSubCommand(new String[]{"list"}, v -> {
            v.say("List of Checkpoints");
            config.listCheckPoint().forEach(p -> {
                v.sender.sendMessage(p + "：Start " + LocStr.fromLocation(config.checkpoints.get(p).startPoint)
                                         + ", End " + LocStr.fromLocation(config.checkpoints.get(p).endPoint));
            });
            return true;
        });

        // ./chkpoint ignoreコマンド
        cm.addSubCommand(new String[]{"ignore"}, v -> {
            if (cpcs != CheckPointCreationStatus.SetEndPoint) {
                rejectCommandWithWrongStatus(v);
                return true;
            }
            Player player = getPlayer(v);
            if (player == null) return true;
            Location loc = player.getLocation().getBlock().getLocation().clone();
            creatingCheckPoint.ignorePoint.add(loc);
            v.say("例外ポイントを設定しました: " + LocStr.fromLocation(loc));
            return true;
        });
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        //プレイヤーが動いたときの処理
        Location oldTo = event.getTo();

        //範囲に入っているチェックポイントを探します。
        Optional<CheckPoint> c = config.checkpoints.values().stream().filter(v -> v.isInRange(oldTo)).findAny();

        //見つかった場合のみ
        c.ifPresent(v -> {
            if (v.ignorePoint.contains(oldTo.getBlock().getLocation()))
                return;
            //そのチェックポイントのスポーンポイントに飛ばします。
            Location spawnPointNew = v.spawnPoint;
            //Pitch, Yaw(始点の向き) は、プレイヤーのもともとのものを保ちます。
            spawnPointNew.setPitch(oldTo.getPitch());
            spawnPointNew.setYaw(oldTo.getYaw());
            event.setTo(spawnPointNew);
        });
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}
